package it.sunnyvale.text4shell.controller;

import org.apache.commons.text.StringSubstitutor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("text4shell")
public class Text4ShellController {

    @RequestMapping(value = "/attack", method = RequestMethod.GET)
    @ResponseBody
    public String attack(@RequestParam(defaultValue="5up3r541y4n") String search) {
        StringSubstitutor interpolator = StringSubstitutor.createInterpolator();
        // String pocstring = "${script:javascript:java.lang.Runtime.getRuntime().exec('touch /tmp/foo')}";
        try{
            String pwn = interpolator.replace(search);
        } catch(Exception e) {
            System.out.println(e);
        }
        return "Search results for: " + search;
    }

}