package sample.payload;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.spi.ObjectFactory;

public class Payload implements ObjectFactory {
    
    static {
        System.out.println("PAYLOAD -- INITIALIZER CALLED");
    }
    
    public Payload() {
        System.out.println("PAYLOAD -- CONSTRUCTOR CALLED");
    }

    @Override
    public String toString() {
        System.out.println("PAYLOAD -- TO STRING CALLED");
        return "PAYLOAD -- RESULT OF TO STRING";
    }

    @Override
    public Object getObjectInstance(Object obj, Name name, Context nameCtx, Hashtable<?, ?> environment) {
        return "PAYLOAD -- RESULT OF NEW INSTANCE";
    }
}
