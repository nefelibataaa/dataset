import java.io.*;

public class Trojan implements Serializable {
    static {
        shout("static block");
    }

    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        shout("writeObject");
    }

    private void readObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        shout("readObject");
    }

    private static void shout(String descr) {
        String msg = "!!! BUSTED !!! (" + descr + ")";
        System.err.println(msg);
//        new RuntimeException(msg).printStackTrace();
        try {
            new File(
                    "/tmp/log4shell-BUSTED-"
                            + System.currentTimeMillis()
                            + "-"
                            + descr.replaceAll("\\s", "_")
            ).createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
