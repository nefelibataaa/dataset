/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.   
 */

package com.pasam.exploitable;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * Simple sprint boot application that servers HTTP GET and POST request on '/'.
 *
 * @author Seshu Pasam
 */
@SpringBootApplication
public class Application extends SpringBootServletInitializer {
  private static final Logger log = LogManager.getLogger(Application.class);

  public static void main(String[] args) {
    log.error("Exploitable application starting");
    SpringApplication.run(Application.class, args);
  }

  @RestController
  public static class Initializer {
    @GetMapping("/")
    public String get() {
      return "<h2>Java application</h2><br><form method=\"post\" action=\"/\">"
          + "<label for=\"user\">Username:</label><br><input type=\"text\" id=\"user\" name=\"user\"><br>"
          + "<label for=\"password\">Password:</label><br><input type=\"password\" id=\"password\" name=\"password\"><br>"
          + "<input type=\"submit\" value=\"Submit\"></form>";
    }

    @PostMapping("/")
    public String post(@RequestParam(name = "user", required = false) String user,
        @RequestParam(name = "password", required = false) String password) {
      log.error("Hello: {}", user);
      return "<h2>Hello: " + user + "</h2>\n";
    }
  }
}
