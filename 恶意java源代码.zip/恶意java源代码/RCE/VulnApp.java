package eu.ubitech.vulnapp;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class VulnApp {
 
 private static final Logger logger = LogManager.getLogger(VulnApp.class);
    
     public static void main(String[] args) {
        System.setProperty("com.sun.jndi.ldap.object.trustURLCodebase", "true");
        String username = args[0];
        logger.error("Logger: " + username);
    }
    
}
